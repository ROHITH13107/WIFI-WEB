import { users as usersTable, type User, type InsertUser, rooms as roomsTable } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Room management methods
  createRoom(roomId: string, hostId: string): Promise<void>;
  getActiveRooms(): Promise<string[]>;
  getRoomViewers(roomId: string): Promise<string[]>;
  closeRoom(roomId: string): Promise<void>;
}

// Map to keep track of viewers for each room
// This is still kept in memory since viewers are transient
// and don't need to be persisted to the database
const roomViewersMap = new Map<string, string[]>();

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    try {
      const result = await db.select().from(usersTable).where(eq(usersTable.id, id));
      return result.length > 0 ? result[0] : undefined;
    } catch (error) {
      console.error('Database error getting user by ID:', error);
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const foundUsers = await db.select().from(usersTable).where(eq(usersTable.username, username));
      return foundUsers.length > 0 ? foundUsers[0] : undefined;
    } catch (error) {
      console.error('Database error getting user by username:', error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const [user] = await db.insert(usersTable).values(insertUser).returning();
      return user;
    } catch (error) {
      console.error('Database error creating user:', error);
      throw new Error('Failed to create user in database');
    }
  }
  
  async createRoom(roomId: string, hostId: string): Promise<void> {
    try {
      // Check if the room already exists
      const existingRooms = await db
        .select()
        .from(roomsTable)
        .where(eq(roomsTable.roomId, roomId));
      
      if (existingRooms.length > 0) {
        // If room exists, update it to be active
        await db
          .update(roomsTable)
          .set({ isActive: true, hostId })
          .where(eq(roomsTable.roomId, roomId));
        console.log(`Updated existing room ${roomId} with host ${hostId}`);
      } else {
        // Create a new room
        await db.insert(roomsTable).values({
          roomId,
          hostId,
          isActive: true,
          createdAt: new Date().toISOString()
        });
        console.log(`Created new room ${roomId} with host ${hostId}`);
      }
      
      // Initialize empty viewers array
      roomViewersMap.set(roomId, []);
    } catch (error) {
      console.error('Database error creating/updating room:', error);
      // Still initialize the in-memory viewers array as a fallback
      roomViewersMap.set(roomId, []);
    }
  }
  
  async getActiveRooms(): Promise<string[]> {
    try {
      const activeRooms = await db
        .select()
        .from(roomsTable)
        .where(eq(roomsTable.isActive, true));
      
      return activeRooms.map(room => room.roomId);
    } catch (error) {
      console.error('Database error getting active rooms:', error);
      // Return rooms we know about in memory as a fallback
      return Array.from(roomViewersMap.keys());
    }
  }
  
  async getRoomViewers(roomId: string): Promise<string[]> {
    // This is an in-memory operation, but we'll still add error handling
    try {
      return roomViewersMap.get(roomId) || [];
    } catch (error) {
      console.error('Error getting room viewers from memory:', error);
      return [];
    }
  }
  
  async closeRoom(roomId: string): Promise<void> {
    try {
      await db
        .update(roomsTable)
        .set({ isActive: false })
        .where(eq(roomsTable.roomId, roomId));
      
      // Clear viewers
      roomViewersMap.delete(roomId);
      console.log(`Room ${roomId} marked as inactive in database`);
    } catch (error) {
      console.error('Database error closing room:', error);
      // Still remove from memory even if DB update failed
      roomViewersMap.delete(roomId);
    }
  }
  
  // Helper method to add viewer to a room
  async addViewerToRoom(roomId: string, viewerId: string): Promise<void> {
    try {
      // First ensure the room exists in the database
      const rooms = await db
        .select()
        .from(roomsTable)
        .where(and(
          eq(roomsTable.roomId, roomId),
          eq(roomsTable.isActive, true)
        ));
      
      // Only add the viewer if the room exists
      if (rooms.length > 0) {
        const viewers = roomViewersMap.get(roomId) || [];
        if (!viewers.includes(viewerId)) {
          viewers.push(viewerId);
          roomViewersMap.set(roomId, viewers);
          console.log(`Added viewer ${viewerId} to room ${roomId}`);
        }
      } else {
        console.warn(`Attempted to add viewer to non-existent room ${roomId}`);
      }
    } catch (error) {
      console.error('Error adding viewer to room:', error);
      // Fallback - add to in-memory map even if db check fails
      const viewers = roomViewersMap.get(roomId) || [];
      if (!viewers.includes(viewerId)) {
        viewers.push(viewerId);
        roomViewersMap.set(roomId, viewers);
      }
    }
  }
  
  // Helper method to remove viewer from a room
  async removeViewerFromRoom(roomId: string, viewerId: string): Promise<void> {
    try {
      const viewers = roomViewersMap.get(roomId) || [];
      const updatedViewers = viewers.filter(id => id !== viewerId);
      roomViewersMap.set(roomId, updatedViewers);
      console.log(`Removed viewer ${viewerId} from room ${roomId}`);
    } catch (error) {
      console.error('Error removing viewer from room:', error);
    }
  }
}

export const storage = new DatabaseStorage();
