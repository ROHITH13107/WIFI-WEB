import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from 'ws';
import { storage } from "./storage";
import { SignalingMessage, ViewerPermission, ViewerInfo, RecordingState } from "@shared/schema";
import { rooms as roomsTable } from "@shared/schema";
import { DatabaseStorage } from "./storage";
import { db } from "./db";

// Map to keep track of clients by room
type ConnectedClient = {
  socket: WebSocket;
  id: string;
  isHost: boolean;
  permission: ViewerPermission;
  nickname?: string;
  joinedAt: number;
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Create WebSocket server on a separate path to avoid conflicts with Vite HMR
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws',
    // Increase ping/pong frequency to keep connection alive
    clientTracking: true,
    // Set max payload size to 16MB to handle video data
    maxPayload: 16 * 1024 * 1024,
    // Disable compression for better performance in Replit environment
    perMessageDeflate: false
  });
  
  // Handle server-level WebSocket errors
  wss.on('error', (error) => {
    console.error('WebSocket server error:', error);
  });
  
  // Log when the server starts and the WebSocket server is initialized
  console.log(`WebSocket server initialized and listening on path: /ws`);
  console.log(`Current number of WebSocket clients: ${wss.clients.size}`);
  
  // Store connected clients by room
  const rooms = new Map<string, Set<ConnectedClient>>();
  
  // Keep connections alive with ping-pong
  function heartbeat(this: WebSocket & { isAlive?: boolean }) {
    this.isAlive = true;
    console.log('Received pong, connection is alive');
    
    // Additional heartbeat extension to prevent premature timeouts
    setTimeout(() => {
      if (this.readyState === WebSocket.OPEN) {
        this.isAlive = true;
        console.log('Extended heartbeat interval to prevent premature closure');
      }
    }, 30000);
  }
  
  // Constants for heartbeat - Use much more aggressive values for Replit environment
  const HEARTBEAT_INTERVAL = 15000; // Check every 15 seconds
  const CLIENT_TIMEOUT = 120000; // Consider client dead after 120 seconds of no pong/ping

  // More reliable connection check with improved heartbeat
  const interval = setInterval(() => {
    if (wss.clients.size === 0) {
      console.log("No clients connected, skipping heartbeat check.");
      return;
    }
    
    console.log(`Checking ${wss.clients.size} WebSocket connections for liveness`);
    
    const now = Date.now();
    
    wss.clients.forEach((ws: WebSocket & { isAlive?: boolean; lastPong?: number; lastPing?: number }) => {
      // Initialize tracking properties if they don't exist
      if (ws.lastPong === undefined) ws.lastPong = now;
      if (ws.lastPing === undefined) ws.lastPing = now;
      
      // Check if client has timed out
      if (now - ws.lastPong > CLIENT_TIMEOUT) {
        console.log(`Terminating inactive connection after ${CLIENT_TIMEOUT}ms without response`);
        return ws.terminate();
      }
      
      // Send ping with error handling
      try {
        // Update ping time
        ws.lastPing = now;
        
        // Send both a standard WebSocket ping and a JSON ping message
        // The standard ping is handled automatically by the WebSocket protocol
        ws.ping();
        
        // Also send a JSON ping that will be processed by our custom client code
        // This acts as a backup in case the client doesn't properly handle WebSocket pings
        ws.send(JSON.stringify({
          type: 'pong',
          timestamp: now
        }));
      } catch (pingError) {
        console.error('Error during heartbeat:', pingError);
      }
    });
  }, HEARTBEAT_INTERVAL);
  
  wss.on('close', () => {
    clearInterval(interval);
  });
  
  wss.on('connection', (socket: WebSocket & { isAlive?: boolean }, request) => {
    console.log('New WebSocket connection established');
    console.log('WebSocket path:', request.url);
    
    // Mark socket as alive and keep it alive much longer
    socket.isAlive = true;
    
    // Replit's environment seems to need more aggressive keeping alive
    const keepSocketAlive = () => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.isAlive = true;
      }
    };
    
    // Mark socket alive every 5 seconds to prevent premature closure
    const keepAliveInterval = setInterval(keepSocketAlive, 5000);
    
    // Clean up interval on socket close
    socket.addEventListener('close', () => {
      clearInterval(keepAliveInterval);
    });
    
    socket.on('pong', heartbeat);
    
    let clientId: string | null = null;
    let currentRoom: string | null = null;
    
    // Create a more aggressive connection keep-alive strategy
    console.log('Sending welcome message to new client');
    try {
      // Immediately mark socket as alive to prevent premature termination
      (socket as any).isAlive = true;
      
      const welcomeMessage = JSON.stringify({
        type: 'welcome',
        message: 'Connection established',
        timestamp: Date.now()
      });
      socket.send(welcomeMessage);
      console.log('Welcome message sent successfully');
      
      // Create a series of ping messages at staggered intervals
      // This helps establish a more reliable connection in Replit's environment
      const pingIntervals = [100, 500, 1000, 2000, 5000];
      
      pingIntervals.forEach((delay, index) => {
        setTimeout(() => {
          if (socket.readyState === WebSocket.OPEN) {
            try {
              console.log(`Sending scheduled ping #${index + 1} to keep connection alive`);
              socket.send(JSON.stringify({
                type: 'ping',
                timestamp: Date.now(),
                pingIndex: index + 1
              }));
              
              // Mark socket as alive at each ping interval 
              (socket as any).isAlive = true;
            } catch (pingError) {
              console.error(`Error sending ping #${index + 1}:`, pingError);
            }
          } else {
            console.log(`Socket already closed before ping #${index + 1}`);
          }
        }, delay);
      });
      
    } catch (welcomeError) {
      console.error('Error sending welcome message:', welcomeError);
    }
    
    socket.on('message', async (message) => {
      try {
        // Critical: Mark socket as alive immediately when any message arrives
        (socket as any).isAlive = true;
        (socket as any).lastPong = Date.now();
        
        // Log the message but limit its length to avoid console spam
        console.log('Received message:', message.toString().substring(0, 100) + '...');
        
        let data: SignalingMessage;
        try {
          data = JSON.parse(message.toString()) as SignalingMessage;
        } catch (parseError) {
          console.error('Failed to parse WebSocket message:', parseError);
          return; // Skip invalid messages
        }
        
        switch (data.type) {
          case 'ping':
            // Handle ping message from client
            // Send pong back immediately
            socket.send(JSON.stringify({
              type: 'pong',
              timestamp: Date.now()
            }));
            return; // Skip further processing for ping messages
            
          case 'permission-request':
            // Handle permission request from a viewer
            if (currentRoom && rooms.has(currentRoom)) {
              // Only forward permission requests to the host
              const host = Array.from(rooms.get(currentRoom) || []).find(client => client.isHost);
              
              if (host && host.socket.readyState === WebSocket.OPEN) {
                host.socket.send(JSON.stringify(data));
                console.log(`Forwarded permission request from ${data.senderId} to host`);
              } else {
                console.log('Host not found or not ready to receive permission request');
                // Send rejection back to the requester
                socket.send(JSON.stringify({
                  type: 'permission-response',
                  roomId: currentRoom,
                  senderId: 'system',
                  receiverId: data.senderId,
                  data: { granted: false, reason: 'Host unavailable' }
                }));
              }
            }
            break;
            
          case 'permission-response':
            // Host responding to a viewer permission request
            if (currentRoom && rooms.has(currentRoom) && data.receiverId) {
              const viewer = Array.from(rooms.get(currentRoom) || []).find(client => client.id === data.receiverId);
              
              if (viewer && viewer.socket.readyState === WebSocket.OPEN) {
                viewer.socket.send(JSON.stringify(data));
                console.log(`Forwarded permission response to ${data.receiverId}`);
                
                // Update the viewer's permission in memory
                if (data.data && typeof data.data.permission === 'string') {
                  // Update the client's permission in memory
                  const viewerClient = Array.from(rooms.get(currentRoom) || []).find(client => client.id === data.receiverId);
                  if (viewerClient) {
                    viewerClient.permission = data.data.permission as ViewerPermission;
                    console.log(`Updated permission for ${data.receiverId} to ${data.data.permission}`);
                  }
                }
              }
            }
            break;
            
          case 'recording-state':
            // Host updating the recording state
            if (currentRoom && rooms.has(currentRoom)) {
              // Broadcast recording state to all viewers
              rooms.get(currentRoom)?.forEach(client => {
                if (!client.isHost && client.socket.readyState === WebSocket.OPEN) {
                  client.socket.send(JSON.stringify(data));
                }
              });
              console.log(`Broadcasting recording state to all viewers in room ${currentRoom}`);
            }
            break;
          
          case 'join':
            // Join or create a room
            clientId = data.senderId;
            currentRoom = data.roomId;
            
            // Check if the room exists in memory
            if (!rooms.has(currentRoom)) {
              // Initialize a new set for this room
              rooms.set(currentRoom, new Set());
              
              // First person to join is the host (camera)
              const isHost = clientId.startsWith('host-');
              rooms.get(currentRoom)?.add({
                socket,
                id: clientId,
                isHost,
                permission: isHost ? 'admin' : 'view',
                joinedAt: Date.now()
              });
              
              // Store the room in the database if this is a host
              if (isHost) {
                await storage.createRoom(currentRoom, clientId);
                console.log(`New room created in database: ${currentRoom} with host ${clientId}`);
              }
              
              // Inform the client they joined successfully
              socket.send(JSON.stringify({
                type: 'joined',
                roomId: currentRoom,
                isHost,
                clients: []
              }));
              
              console.log(`New room created: ${currentRoom} with client ${clientId}, isHost: ${isHost}`);
              
            } else {
              // Room exists in memory, add client
              const isHost = clientId.startsWith('host-');
              
              // Add to existing room
              rooms.get(currentRoom)?.add({
                socket,
                id: clientId,
                isHost,
                permission: isHost ? 'admin' : 'view',
                joinedAt: Date.now()
              });
              
              // If this is a host reconnecting, no need to handle as viewer
              if (isHost) {
                socket.send(JSON.stringify({
                  type: 'joined',
                  roomId: currentRoom,
                  isHost: true,
                  clients: []
                }));
              } else {
                // This is a viewer, add to the viewers list
                await storage.addViewerToRoom(currentRoom, clientId);
                
                // Get the host client
                const host = Array.from(rooms.get(currentRoom) || []).find(client => client.isHost);
                
                // Inform host about the new viewer
                if (host) {
                  console.log(`Informing host about new viewer: ${clientId}`);
                  host.socket.send(JSON.stringify({
                    type: 'viewer-joined',
                    roomId: currentRoom,
                    clientId
                  }));
                }
                
                // Inform the client about successful join
                const clientIds = Array.from(rooms.get(currentRoom) || [])
                  .filter(client => client.id !== clientId)
                  .map(client => ({ id: client.id, isHost: client.isHost }));
                
                socket.send(JSON.stringify({
                  type: 'joined',
                  roomId: currentRoom,
                  isHost: false,
                  clients: clientIds
                }));
              }
            }
            
            console.log(`Client ${clientId} joined room ${currentRoom}. Current clients: ${rooms.get(currentRoom)?.size}`);
            break;
            
          case 'offer':
            console.log(`Received offer from ${data.senderId} to ${data.receiverId}`);
            // Forward messages to the intended recipient
            if (currentRoom && rooms.has(currentRoom)) {
              const recipient = Array.from(rooms.get(currentRoom) || [])
                .find(client => client.id === data.receiverId);
              
              if (recipient && recipient.socket.readyState === WebSocket.OPEN) {
                recipient.socket.send(JSON.stringify(data));
                console.log(`Forwarded offer to ${data.receiverId}`);
              } else {
                console.log(`Recipient ${data.receiverId} not found or not ready`);
              }
            }
            break;
            
          case 'answer':
            console.log(`Received answer from ${data.senderId} to ${data.receiverId}`);
            // Forward answer to the intended recipient
            if (currentRoom && rooms.has(currentRoom)) {
              const recipient = Array.from(rooms.get(currentRoom) || [])
                .find(client => client.id === data.receiverId);
              
              if (recipient && recipient.socket.readyState === WebSocket.OPEN) {
                recipient.socket.send(JSON.stringify(data));
                console.log(`Forwarded answer to ${data.receiverId}`);
              } else {
                console.log(`Recipient ${data.receiverId} not found or not ready`);
              }
            }
            break;
            
          case 'ice-candidate':
            // Forward ICE candidate to the intended recipient
            if (currentRoom && rooms.has(currentRoom)) {
              const recipient = Array.from(rooms.get(currentRoom) || [])
                .find(client => client.id === data.receiverId);
              
              if (recipient && recipient.socket.readyState === WebSocket.OPEN) {
                recipient.socket.send(JSON.stringify(data));
              }
            }
            break;
            
          case 'leave':
            // Handle client leaving
            await handleClientDisconnect();
            break;
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    socket.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
    
    socket.on('close', async () => {
      console.log('WebSocket connection closed');
      await handleClientDisconnect();
    });
    
    async function handleClientDisconnect() {
      // Only process disconnection if we have all required identifiers
      if (!currentRoom || !clientId) {
        console.log('Client disconnected before joining a room');
        return;
      }
      
      // Check if room exists
      if (!rooms.has(currentRoom)) {
        console.log(`Room ${currentRoom} not found during client disconnect`);
        return;
      }
      
      try {
        const roomClients = rooms.get(currentRoom);
        const client = Array.from(roomClients || []).find(c => c.id === clientId);
        
        if (!client) {
          console.log(`Client ${clientId} not found in room ${currentRoom} during disconnect`);
          return;
        }
        
        console.log(`Processing client disconnect: ${clientId} from room ${currentRoom}`);
        
        // Remove client from memory
        roomClients?.delete(client);
        
        // If this is a viewer, remove from the database viewer list
        if (!client.isHost) {
          await storage.removeViewerFromRoom(currentRoom, clientId);
          console.log(`Viewer ${clientId} removed from database for room ${currentRoom}`);
        }
        
        // Notify other clients about the disconnect
        roomClients?.forEach(otherClient => {
          try {
            if (otherClient.socket.readyState === WebSocket.OPEN) {
              otherClient.socket.send(JSON.stringify({
                type: 'client-left',
                roomId: currentRoom,
                clientId
              }));
            }
          } catch (notifyError) {
            console.error(`Error notifying client ${otherClient.id} about disconnect:`, notifyError);
          }
        });
        
        // Check if room is empty or if host left
        if (roomClients?.size === 0 || client.isHost) {
          // Close the room in the database
          await storage.closeRoom(currentRoom);
          // Remove the room from memory
          rooms.delete(currentRoom);
          console.log(`Room ${currentRoom} has been closed in database because it's empty or host left`);
        }
        
        console.log(`Client ${clientId} left room ${currentRoom}. Remaining clients: ${roomClients?.size}`);
      } catch (error) {
        console.error(`Error during client disconnect handling:`, error);
      }
    }
  });
  
  // API Routes
  app.get('/api/status', async (req, res) => {
    try {
      const activeRooms = await storage.getActiveRooms();
      res.json({ 
        status: 'online', 
        timestamp: new Date().toISOString(),
        rooms: activeRooms.length 
      });
    } catch (error) {
      console.error('Error in status endpoint:', error);
      res.status(500).json({ 
        status: 'error', 
        message: 'Failed to get system status' 
      });
    }
  });
  
  app.get('/api/rooms', async (req, res) => {
    try {
      // Get active rooms from database
      const activeRoomIds = await storage.getActiveRooms();
      
      // Combine with in-memory data about current connections
      const roomData = await Promise.all(activeRoomIds.map(async (roomId) => {
        try {
          const roomClients = rooms.get(roomId);
          const viewers = await storage.getRoomViewers(roomId);
          
          return {
            roomId,
            clientCount: roomClients?.size || 0,
            viewerCount: viewers.length,
            hasHost: roomClients ? Array.from(roomClients).some(client => client.isHost) : false,
            active: true
          };
        } catch (roomError) {
          console.error(`Error processing room ${roomId}:`, roomError);
          // Return basic info if detailed info fails
          return {
            roomId,
            clientCount: 0,
            viewerCount: 0,
            hasHost: false,
            active: true,
            error: 'Failed to get complete room data'
          };
        }
      }));
      
      res.json(roomData);
    } catch (error) {
      console.error('Error in rooms endpoint:', error);
      res.status(500).json({ 
        error: 'Failed to retrieve rooms data',
        rooms: []
      });
    }
  });
  
  // API endpoint to get room statistics
  app.get('/api/stats', async (req, res) => {
    try {
      // Query the database for room statistics
      const activeRooms = await storage.getActiveRooms();
      const activeRoomCount = activeRooms.length;
      
      // Get all rooms from the database
      const allRooms = await db.select().from(roomsTable);
      const totalRoomsCount = allRooms.length;
      
      // Get a count of all current connections
      let totalConnections = 0;
      let totalHosts = 0;
      let totalViewers = 0;
      
      rooms.forEach(clients => {
        totalConnections += clients.size;
        clients.forEach(client => {
          if (client.isHost) {
            totalHosts++;
          } else {
            totalViewers++;
          }
        });
      });
      
      res.json({
        activeRooms: activeRoomCount,
        totalRoomsCreated: totalRoomsCount,
        roomList: allRooms.map(room => ({
          id: room.id,
          roomId: room.roomId,
          isActive: room.isActive,
          hostId: room.hostId,
          createdAt: room.createdAt,
        })),
        currentConnections: {
          total: totalConnections,
          hosts: totalHosts,
          viewers: totalViewers
        },
        serverUptime: Math.floor(process.uptime()) + ' seconds',
        serverStartedAt: new Date(Date.now() - process.uptime() * 1000).toISOString(),
        currentTime: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error in stats endpoint:', error);
      res.status(500).json({ 
        error: 'Failed to retrieve statistics',
        message: error instanceof Error ? error.message : 'Unknown error',
        stats: {
          activeRooms: 0,
          totalRoomsCreated: 0,
          currentConnections: { total: 0, hosts: 0, viewers: 0 }
        }
      });
    }
  });

  return httpServer;
}
