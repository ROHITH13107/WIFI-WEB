import { useState } from "react";
import { X, Copy, Settings as SettingsIcon, ChevronRight, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { AppSettings } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface SettingsPanelProps {
  open: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSettingsChange: (settings: AppSettings) => void;
  roomId: string;
}

export default function SettingsPanel({
  open,
  onClose,
  settings,
  onSettingsChange,
  roomId
}: SettingsPanelProps) {
  const { toast } = useToast();
  const connectionUrl = `${window.location.origin}/viewer/${roomId}`;
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  const handleCopy = () => {
    navigator.clipboard.writeText(connectionUrl);
    toast({
      title: "Copied!",
      description: "Connection URL copied to clipboard"
    });
  };
  
  const updateCameraSettings = (key: keyof AppSettings['camera'], value: any) => {
    onSettingsChange({
      ...settings,
      camera: {
        ...settings.camera,
        [key]: value
      }
    });
  };
  
  const updateConnectionSettings = (key: keyof AppSettings['connection'], value: any) => {
    onSettingsChange({
      ...settings,
      connection: {
        ...settings.connection,
        [key]: value
      }
    });
  };
  
  const updateSystemSettings = (key: keyof AppSettings['system'], value: any) => {
    onSettingsChange({
      ...settings,
      system: {
        ...settings.system,
        [key]: value
      }
    });
  };
  
  return (
    <div className={`fixed inset-0 bg-black/80 z-20 transform transition-transform duration-300 ${open ? 'translate-x-0' : 'translate-x-full'}`}>
      <div className="absolute right-0 top-0 bottom-0 bg-neutral-900 w-full max-w-md p-5 shadow-lg overflow-y-auto">
        <div className="flex justify-between items-center mb-5">
          <h2 className="text-xl font-medium flex items-center">
            <SettingsIcon className="h-5 w-5 mr-2" />
            Settings
          </h2>
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="text-xs"
            >
              {showAdvanced ? "Basic Settings" : "Advanced Settings"}
            </Button>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        <Tabs defaultValue="camera" className="w-full">
          <TabsList className="grid grid-cols-3 mb-4 bg-neutral-800">
            <TabsTrigger value="camera">Camera</TabsTrigger>
            <TabsTrigger value="connection">Connection</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
          </TabsList>
          
          {/* Camera Settings Tab */}
          <TabsContent value="camera" className="space-y-4">
            <Accordion type="single" collapsible defaultValue="basic" className="w-full">
              {/* Basic Camera Settings */}
              <AccordionItem value="basic" className="border-b border-neutral-800">
                <AccordionTrigger className="text-sm font-medium">
                  Basic Camera Settings
                </AccordionTrigger>
                <AccordionContent className="space-y-4 pt-2">
                  {/* Resolution selector */}
                  <div>
                    <Label className="text-sm text-neutral-400">Resolution</Label>
                    <Select 
                      value={settings.camera.resolution} 
                      onValueChange={(value) => updateCameraSettings('resolution', value)}
                    >
                      <SelectTrigger className="bg-neutral-800 border-neutral-700">
                        <SelectValue placeholder="Select resolution" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="720p">720p (HD) - Recommended</SelectItem>
                        <SelectItem value="1080p">1080p (Full HD)</SelectItem>
                        <SelectItem value="480p">480p (SD)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {/* Frame rate */}
                  <div>
                    <Label className="text-sm text-neutral-400">Frame Rate</Label>
                    <Select 
                      value={settings.camera.frameRate.toString()} 
                      onValueChange={(value) => updateCameraSettings('frameRate', parseInt(value))}
                    >
                      <SelectTrigger className="bg-neutral-800 border-neutral-700">
                        <SelectValue placeholder="Select frame rate" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30">30 fps - Recommended</SelectItem>
                        <SelectItem value="60">60 fps</SelectItem>
                        <SelectItem value="15">15 fps (Battery Saver)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {/* Aspect ratio */}
                  <div>
                    <Label className="text-sm text-neutral-400">Aspect Ratio</Label>
                    <Select 
                      value={settings.camera.aspectRatio} 
                      onValueChange={(value) => updateCameraSettings('aspectRatio', value as '16:9' | '4:3' | '1:1')}
                    >
                      <SelectTrigger className="bg-neutral-800 border-neutral-700">
                        <SelectValue placeholder="Select aspect ratio" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="16:9">16:9 (Widescreen)</SelectItem>
                        <SelectItem value="4:3">4:3 (Standard)</SelectItem>
                        <SelectItem value="1:1">1:1 (Square)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {/* Flash toggle */}
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm">Flash</p>
                      <p className="text-xs text-neutral-500">Use camera flash when streaming</p>
                    </div>
                    <Switch 
                      checked={settings.camera.useFlash}
                      onCheckedChange={(checked) => updateCameraSettings('useFlash', checked)}
                    />
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              {/* Advanced Camera Settings */}
              {showAdvanced && (
                <AccordionItem value="advanced" className="border-b border-neutral-800">
                  <AccordionTrigger className="text-sm font-medium">
                    Advanced Camera Settings
                  </AccordionTrigger>
                  <AccordionContent className="space-y-4 pt-2">
                    {/* Focus Mode */}
                    <div>
                      <Label className="text-sm text-neutral-400">Focus Mode</Label>
                      <Select 
                        value={settings.camera.focusMode} 
                        onValueChange={(value) => updateCameraSettings('focusMode', value as 'auto' | 'continuous' | 'manual')}
                      >
                        <SelectTrigger className="bg-neutral-800 border-neutral-700">
                          <SelectValue placeholder="Select focus mode" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="auto">Auto Focus</SelectItem>
                          <SelectItem value="continuous">Continuous Focus</SelectItem>
                          <SelectItem value="manual">Manual Focus</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {/* White Balance */}
                    <div>
                      <Label className="text-sm text-neutral-400">White Balance</Label>
                      <Select 
                        value={settings.camera.whiteBalance} 
                        onValueChange={(value) => updateCameraSettings('whiteBalance', value as any)}
                      >
                        <SelectTrigger className="bg-neutral-800 border-neutral-700">
                          <SelectValue placeholder="Select white balance" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="auto">Auto</SelectItem>
                          <SelectItem value="sunny">Sunny / Daylight</SelectItem>
                          <SelectItem value="cloudy">Cloudy</SelectItem>
                          <SelectItem value="fluorescent">Fluorescent</SelectItem>
                          <SelectItem value="incandescent">Incandescent</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {/* Zoom level */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <Label className="text-sm text-neutral-400">Zoom Level</Label>
                        <span className="text-xs text-neutral-500">{settings.camera.zoom.toFixed(1)}x</span>
                      </div>
                      <Slider 
                        min={1} 
                        max={5} 
                        step={0.1} 
                        value={[settings.camera.zoom]} 
                        onValueChange={(values) => updateCameraSettings('zoom', values[0])}
                        className="py-2"
                      />
                    </div>
                    
                    {/* Exposure Compensation */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <Label className="text-sm text-neutral-400">Exposure Compensation</Label>
                        <span className="text-xs text-neutral-500">{settings.camera.exposureCompensation > 0 ? '+' : ''}{settings.camera.exposureCompensation}</span>
                      </div>
                      <Slider 
                        min={-2} 
                        max={2} 
                        step={0.5} 
                        value={[settings.camera.exposureCompensation]} 
                        onValueChange={(values) => updateCameraSettings('exposureCompensation', values[0])}
                        className="py-2"
                      />
                    </div>
                  </AccordionContent>
                </AccordionItem>
              )}
            </Accordion>
          </TabsContent>
          
          {/* Connection Settings Tab */}
          <TabsContent value="connection" className="space-y-4">
            <Accordion type="single" collapsible defaultValue="basic" className="w-full">
              {/* Basic Connection Settings */}
              <AccordionItem value="basic" className="border-b border-neutral-800">
                <AccordionTrigger className="text-sm font-medium">
                  Basic Connection Settings
                </AccordionTrigger>
                <AccordionContent className="space-y-4 pt-2">
                  {/* Streaming URL */}
                  <div>
                    <Label className="text-sm text-neutral-400">Stream URL</Label>
                    <div className="flex">
                      <Input 
                        type="text" 
                        value={connectionUrl} 
                        readOnly 
                        className="bg-neutral-800 border-neutral-700 rounded-r-none"
                      />
                      <Button 
                        className="bg-primary rounded-l-none" 
                        onClick={handleCopy}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {/* Quality settings */}
                  <div>
                    <Label className="text-sm text-neutral-400">Streaming Quality</Label>
                    <Select 
                      value={settings.connection.streamingQuality} 
                      onValueChange={(value) => updateConnectionSettings('streamingQuality', value as any)}
                    >
                      <SelectTrigger className="bg-neutral-800 border-neutral-700">
                        <SelectValue placeholder="Select quality" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="balanced">Balanced (Recommended)</SelectItem>
                        <SelectItem value="high">High Quality</SelectItem>
                        <SelectItem value="low">Low Latency</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {/* Auto-reconnect toggle */}
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm">Auto Reconnect</p>
                      <p className="text-xs text-neutral-500">Automatically reconnect if connection lost</p>
                    </div>
                    <Switch 
                      checked={settings.connection.autoReconnect}
                      onCheckedChange={(checked) => updateConnectionSettings('autoReconnect', checked)}
                    />
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              {/* Advanced Connection Settings */}
              {showAdvanced && (
                <AccordionItem value="advanced" className="border-b border-neutral-800">
                  <AccordionTrigger className="text-sm font-medium">
                    Advanced Connection Settings
                  </AccordionTrigger>
                  <AccordionContent className="space-y-4 pt-2">
                    {/* Max Bitrate */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <Label className="text-sm text-neutral-400">Maximum Bitrate</Label>
                        <span className="text-xs text-neutral-500">{settings.connection.maxBitrate} kbps</span>
                      </div>
                      <Slider 
                        min={250} 
                        max={5000} 
                        step={250} 
                        value={[settings.connection.maxBitrate]} 
                        onValueChange={(values) => updateConnectionSettings('maxBitrate', values[0])}
                        className="py-2"
                      />
                    </div>
                    
                    {/* Keyframe Interval */}
                    <div>
                      <div className="flex justify-between mb-1">
                        <Label className="text-sm text-neutral-400">Keyframe Interval</Label>
                        <span className="text-xs text-neutral-500">{settings.connection.keyframeInterval} seconds</span>
                      </div>
                      <Slider 
                        min={1} 
                        max={5} 
                        step={1} 
                        value={[settings.connection.keyframeInterval]} 
                        onValueChange={(values) => updateConnectionSettings('keyframeInterval', values[0])}
                        className="py-2"
                      />
                      <p className="text-xs text-neutral-500 mt-1">Lower values = better seeking, higher values = smaller file size</p>
                    </div>
                    
                    {/* ICE Transport Policy */}
                    <div>
                      <Label className="text-sm text-neutral-400">ICE Transport Policy</Label>
                      <Select 
                        value={settings.connection.iceTransportPolicy} 
                        onValueChange={(value) => updateConnectionSettings('iceTransportPolicy', value as 'all' | 'relay')}
                      >
                        <SelectTrigger className="bg-neutral-800 border-neutral-700">
                          <SelectValue placeholder="Select policy" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All (Default)</SelectItem>
                          <SelectItem value="relay">Relay Only (More stable but higher latency)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {/* STUN/TURN Server Options */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm">Use STUN Servers</p>
                          <p className="text-xs text-neutral-500">Helps establish direct connections</p>
                        </div>
                        <Switch 
                          checked={settings.connection.useStunServers}
                          onCheckedChange={(checked) => updateConnectionSettings('useStunServers', checked)}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm">Use TURN Fallback</p>
                          <p className="text-xs text-neutral-500">Uses relay servers when direct connection fails</p>
                        </div>
                        <Switch 
                          checked={settings.connection.useTurnServers}
                          onCheckedChange={(checked) => updateConnectionSettings('useTurnServers', checked)}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm">DTLS Encryption</p>
                          <p className="text-xs text-neutral-500">Encrypted media transport</p>
                        </div>
                        <Switch 
                          checked={settings.connection.useDtls}
                          onCheckedChange={(checked) => updateConnectionSettings('useDtls', checked)}
                        />
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              )}
            </Accordion>
          </TabsContent>
          
          {/* System Settings Tab */}
          <TabsContent value="system" className="space-y-4">
            <Accordion type="single" collapsible defaultValue="basic" className="w-full">
              {/* Basic System Settings */}
              <AccordionItem value="basic" className="border-b border-neutral-800">
                <AccordionTrigger className="text-sm font-medium">
                  Basic System Settings
                </AccordionTrigger>
                <AccordionContent className="space-y-4 pt-2">
                  {/* Keep awake toggle */}
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm">Keep Screen On</p>
                      <p className="text-xs text-neutral-500">Prevent device from sleeping while streaming</p>
                    </div>
                    <Switch 
                      checked={settings.system.keepScreenOn}
                      onCheckedChange={(checked) => updateSystemSettings('keepScreenOn', checked)}
                    />
                  </div>
                  
                  {/* Power saving toggle */}
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm">Battery Optimization</p>
                      <p className="text-xs text-neutral-500">Reduce quality to extend battery life</p>
                    </div>
                    <Switch 
                      checked={settings.system.batteryOptimization}
                      onCheckedChange={(checked) => updateSystemSettings('batteryOptimization', checked)}
                    />
                  </div>
                  
                  {/* Device Nickname */}
                  <div>
                    <Label className="text-sm text-neutral-400">Device Nickname</Label>
                    <Input 
                      type="text" 
                      value={settings.system.deviceNickname} 
                      onChange={(e) => updateSystemSettings('deviceNickname', e.target.value)}
                      className="bg-neutral-800 border-neutral-700"
                    />
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              {/* Advanced System Settings */}
              {showAdvanced && (
                <AccordionItem value="advanced" className="border-b border-neutral-800">
                  <AccordionTrigger className="text-sm font-medium">
                    Advanced System Settings
                  </AccordionTrigger>
                  <AccordionContent className="space-y-4 pt-2">
                    {/* Record sessions toggle */}
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm">Record Sessions</p>
                        <p className="text-xs text-neutral-500">Save video streams locally</p>
                      </div>
                      <Switch 
                        checked={settings.system.recordSessions}
                        onCheckedChange={(checked) => updateSystemSettings('recordSessions', checked)}
                      />
                    </div>
                    
                    {/* Viewer connect notifications */}
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm">Connect Notifications</p>
                        <p className="text-xs text-neutral-500">Get notified when viewers connect</p>
                      </div>
                      <Switch 
                        checked={settings.system.notifyOnViewerConnect}
                        onCheckedChange={(checked) => updateSystemSettings('notifyOnViewerConnect', checked)}
                      />
                    </div>
                    
                    {/* Privacy mode */}
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm">Privacy Mode</p>
                        <p className="text-xs text-neutral-500">Blur background or apply privacy filter</p>
                      </div>
                      <Switch 
                        checked={settings.system.privacyMode}
                        onCheckedChange={(checked) => updateSystemSettings('privacyMode', checked)}
                      />
                    </div>
                  </AccordionContent>
                </AccordionItem>
              )}
            </Accordion>
          </TabsContent>
        </Tabs>
        
        <div className="pt-4 mt-4 border-t border-neutral-800 space-y-2">
          <Button variant="outline" className="w-full bg-neutral-800 text-white hover:bg-neutral-700">
            About WiFi Camera
          </Button>
          
          <Button 
            variant="default" 
            className="w-full"
            onClick={onClose}
          >
            Apply Settings
          </Button>
        </div>
      </div>
    </div>
  );
}
