import { Wifi, BatteryMedium, BatteryFull, BatteryLow, BatteryWarning, BatteryCharging, Users } from "lucide-react";
import StatusIndicator from "./StatusIndicator";
import { ThemeToggle } from "./ThemeToggle";

interface HeaderProps {
  connectionStatus: string;
  batteryLevel: number | null;
  isCharging: boolean;
  viewerCount: number;
}

export default function Header({
  connectionStatus,
  batteryLevel,
  isCharging,
  viewerCount
}: HeaderProps) {
  // Format battery level text
  const batteryText = batteryLevel !== null ? `${Math.round(batteryLevel * 100)}%` : 'N/A';
  
  // Get battery icon based on level and charging status
  const getBatteryIcon = () => {
    if (isCharging) return <BatteryCharging className="h-4 w-4 mr-1" />;
    
    if (batteryLevel === null) return <BatteryMedium className="h-4 w-4 mr-1" />;
    
    if (batteryLevel > 0.8) return <BatteryFull className="h-4 w-4 mr-1" />;
    if (batteryLevel > 0.4) return <BatteryMedium className="h-4 w-4 mr-1" />;
    if (batteryLevel > 0.2) return <BatteryLow className="h-4 w-4 mr-1" />;
    return <BatteryWarning className="h-4 w-4 mr-1" />;
  };
  
  return (
    <header className="flex justify-between items-center p-4 bg-background/80 backdrop-blur-sm border-b z-10 fixed top-0 left-0 right-0">
      <div className="flex items-center">
        <Wifi className="h-5 w-5 mr-2" />
        <div className="flex flex-col">
          <h1 className="text-lg font-medium">WiFi Camera</h1>
          <div className="flex items-center text-xs">
            <StatusIndicator status={connectionStatus as any} />
          </div>
        </div>
      </div>
      
      <div className="flex items-center gap-3">
        {/* Battery status */}
        <div className="flex items-center text-sm">
          {getBatteryIcon()}
          <span>{batteryText}</span>
        </div>
        
        {/* Viewer count */}
        <div className="flex items-center text-sm">
          <Users className="h-4 w-4 mr-1" />
          <span>{viewerCount} {viewerCount === 1 ? 'viewer' : 'viewers'}</span>
        </div>

        {/* Theme toggle */}
        <ThemeToggle />
      </div>
    </header>
  );
}
