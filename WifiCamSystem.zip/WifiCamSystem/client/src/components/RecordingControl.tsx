import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Circle, 
  StopCircle, 
  Clock, 
  AlertTriangle, 
  Save
} from 'lucide-react';
import { RecordingState } from '@shared/schema';
import { 
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

interface RecordingControlProps {
  stream: MediaStream | null;
  isHost: boolean;
  onRecordingStateChange?: (state: RecordingState) => void;
  recordingState: RecordingState;
}

export default function RecordingControl({
  stream,
  isHost,
  onRecordingStateChange,
  recordingState,
}: RecordingControlProps) {
  const [recorder, setRecorder] = useState<MediaRecorder | null>(null);
  const [recordedChunks, setRecordedChunks] = useState<Blob[]>([]);
  const [recordingTime, setRecordingTime] = useState<number>(0);
  const [timerInterval, setTimerInterval] = useState<number | null>(null);
  const { toast } = useToast();

  // Initialize MediaRecorder when stream is available
  useEffect(() => {
    if (!stream) return;
    
    try {
      // Ensure we're capturing both audio and video
      console.log('Setting up MediaRecorder with audio tracks:', stream.getAudioTracks().length);
      
      // Create recorder with audio and video
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'video/webm;codecs=vp9,opus',
        videoBitsPerSecond: 2500000, // 2.5 Mbps
        audioBitsPerSecond: 128000   // 128 kbps audio
      });
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          setRecordedChunks((prev) => [...prev, event.data]);
        }
      };
      
      setRecorder(mediaRecorder);
    } catch (error) {
      console.error('Error creating MediaRecorder:', error);
      toast({
        title: 'Recording Error',
        description: 'Could not initialize recording. Your browser may not support this feature.',
        variant: 'destructive',
      });
    }
    
    return () => {
      if (recorder && recorder.state === 'recording') {
        recorder.stop();
      }
      if (timerInterval) {
        clearInterval(timerInterval);
      }
    };
  }, [stream, toast]);

  // Update UI based on recording state changes from external sources
  useEffect(() => {
    if (recordingState.isRecording && !timerInterval) {
      // Start timer
      const startTime = recordingState.startTime || Date.now();
      setRecordingTime(Math.floor((Date.now() - startTime) / 1000));
      
      const interval = window.setInterval(() => {
        const startTime = recordingState.startTime || Date.now();
        setRecordingTime(Math.floor((Date.now() - startTime) / 1000));
      }, 1000);
      
      setTimerInterval(interval);
    } else if (!recordingState.isRecording && timerInterval) {
      // Stop timer
      clearInterval(timerInterval);
      setTimerInterval(null);
    }
    
    return () => {
      if (timerInterval) {
        clearInterval(timerInterval);
      }
    };
  }, [recordingState, timerInterval]);

  // Format time as MM:SS or HH:MM:SS
  const formatTime = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    
    if (hours > 0) {
      return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
    
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const startRecording = () => {
    if (!recorder || !isHost) return;
    
    try {
      // Reset recorded chunks
      setRecordedChunks([]);
      
      // Start recording
      recorder.start(1000); // Capture chunks every second
      
      // Update recording state
      const newState: RecordingState = {
        isRecording: true,
        startTime: Date.now(),
      };
      
      if (onRecordingStateChange) {
        onRecordingStateChange(newState);
      }
      
      // Start timer
      const interval = window.setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
      
      setTimerInterval(interval);
      setRecordingTime(0);
      
      toast({
        title: 'Recording Started',
        description: 'Your session is now being recorded.',
      });
    } catch (error) {
      console.error('Error starting recording:', error);
      toast({
        title: 'Recording Error',
        description: 'Failed to start recording.',
        variant: 'destructive',
      });
    }
  };

  const stopRecording = () => {
    if (!recorder || !isHost) return;
    
    try {
      if (recorder.state === 'recording') {
        recorder.stop();
      }
      
      // Update recording state
      const newState: RecordingState = {
        isRecording: false,
        duration: recordingTime,
      };
      
      if (onRecordingStateChange) {
        onRecordingStateChange(newState);
      }
      
      // Stop timer
      if (timerInterval) {
        clearInterval(timerInterval);
        setTimerInterval(null);
      }
      
      toast({
        title: 'Recording Stopped',
        description: `Recorded for ${formatTime(recordingTime)}.`,
      });
    } catch (error) {
      console.error('Error stopping recording:', error);
      toast({
        title: 'Recording Error',
        description: 'Failed to stop recording.',
        variant: 'destructive',
      });
    }
  };

  const downloadRecording = () => {
    if (recordedChunks.length === 0) {
      toast({
        title: 'No Recording Available',
        description: 'There is no recording to download.',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      // Create a blob from the recorded chunks
      const blob = new Blob(recordedChunks, { type: 'video/webm' });
      
      // Create download link
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const fileName = `wifi-camera-recording-${timestamp}.webm`;
      
      a.href = url;
      a.download = fileName;
      a.click();
      
      // Clean up
      URL.revokeObjectURL(url);
      
      toast({
        title: 'Recording Downloaded',
        description: `Saved as ${fileName}`,
      });
    } catch (error) {
      console.error('Error downloading recording:', error);
      toast({
        title: 'Download Error',
        description: 'Failed to download recording.',
        variant: 'destructive',
      });
    }
  };

  // Display for non-host viewers
  if (!isHost) {
    return (
      <div className="flex items-center gap-2">
        {recordingState.isRecording ? (
          <div className="flex items-center gap-2">
            <Badge variant="destructive" className="animate-pulse">
              <Circle className="w-3 h-3 mr-1 fill-current" />
              LIVE
            </Badge>
            <span className="text-xs text-muted-foreground flex items-center">
              <Clock className="w-3 h-3 mr-1" />
              {formatTime(recordingTime)}
            </span>
          </div>
        ) : (
          <Badge variant="outline">Not Recording</Badge>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col sm:flex-row items-center gap-2">
      {recordingState.isRecording ? (
        <>
          <Badge variant="destructive" className="animate-pulse">
            <Circle className="w-3 h-3 mr-1 fill-current" />
            Recording {formatTime(recordingTime)}
          </Badge>
          
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="destructive"
                size="sm"
                onClick={stopRecording}
              >
                <StopCircle className="w-4 h-4 mr-1" />
                Stop
              </Button>
            </TooltipTrigger>
            <TooltipContent>Stop Recording</TooltipContent>
          </Tooltip>
        </>
      ) : (
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="secondary"
              size="sm"
              onClick={startRecording}
              disabled={!stream}
            >
              <Circle className="w-4 h-4 mr-1 fill-current text-red-500" />
              Record
            </Button>
          </TooltipTrigger>
          <TooltipContent>Start Recording</TooltipContent>
        </Tooltip>
      )}
      
      {recordedChunks.length > 0 && !recordingState.isRecording && (
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              onClick={downloadRecording}
            >
              <Save className="w-4 h-4 mr-1" />
              Save
            </Button>
          </TooltipTrigger>
          <TooltipContent>Download Recording</TooltipContent>
        </Tooltip>
      )}
    </div>
  );
}