import { Button } from "@/components/ui/button";
import { Settings, Video, CameraOff, SwitchCamera } from "lucide-react";

interface CameraControlsProps {
  isStreaming: boolean;
  onStartStreaming: () => void;
  onStopStreaming: () => void;
  onToggleCamera: () => void;
  onToggleSettings: () => void;
}

export default function CameraControls({
  isStreaming,
  onStartStreaming,
  onStopStreaming,
  onToggleCamera,
  onToggleSettings
}: CameraControlsProps) {
  return (
    <div className="bg-neutral-900 p-4 border-t border-neutral-800 z-10">
      <div className="flex justify-between items-center">
        {/* Settings button */}
        <Button 
          variant="ghost" 
          className="w-12 h-12 rounded-full flex items-center justify-center text-neutral-200 hover:bg-neutral-800"
          onClick={onToggleSettings}
        >
          <Settings className="h-6 w-6" />
        </Button>
        
        {/* Stream toggle button */}
        <Button 
          className={`w-16 h-16 rounded-full flex items-center justify-center shadow-lg ${
            isStreaming ? 'bg-red-500 hover:bg-red-600' : 'bg-primary hover:bg-primary/90'
          }`}
          onClick={isStreaming ? onStopStreaming : onStartStreaming}
        >
          {isStreaming ? (
            <CameraOff className="h-8 w-8" />
          ) : (
            <Video className="h-8 w-8" />
          )}
        </Button>
        
        {/* Camera switch button */}
        <Button 
          variant="ghost" 
          className="w-12 h-12 rounded-full flex items-center justify-center text-neutral-200 hover:bg-neutral-800"
          onClick={onToggleCamera}
        >
          <SwitchCamera className="h-6 w-6" />
        </Button>
      </div>
    </div>
  );
}
