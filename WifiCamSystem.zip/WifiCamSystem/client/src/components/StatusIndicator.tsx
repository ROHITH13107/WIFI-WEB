interface StatusIndicatorProps {
  status: 'connected' | 'connecting' | 'disconnected' | 'error';
}

export default function StatusIndicator({ status }: StatusIndicatorProps) {
  const getStatusColor = () => {
    switch (status) {
      case 'connected':
        return 'bg-green-500';
      case 'connecting':
        return 'bg-amber-500';
      case 'disconnected':
        return 'bg-neutral-500';
      case 'error':
        return 'bg-red-500';
      default:
        return 'bg-neutral-500';
    }
  };
  
  const getStatusText = () => {
    switch (status) {
      case 'connected':
        return 'Connected';
      case 'connecting':
        return 'Connecting...';
      case 'disconnected':
        return 'Disconnected';
      case 'error':
        return 'Connection Error';
      default:
        return 'Unknown';
    }
  };
  
  return (
    <div className="flex items-center">
      <span className={`h-2 w-2 rounded-full ${getStatusColor()} mr-1 animate-pulse`}></span>
      <span className="text-xs">{getStatusText()}</span>
    </div>
  );
}
