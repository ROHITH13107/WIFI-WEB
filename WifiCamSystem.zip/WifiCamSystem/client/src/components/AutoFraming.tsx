import { useRef, useEffect, useState } from 'react';
import * as tf from '@tensorflow/tfjs';

interface AutoFramingProps {
  videoRef: React.RefObject<HTMLVideoElement>;
  stream: MediaStream | null;
  enabled: boolean;
  sensitivity?: number; // How sensitive the movement detection should be (0-1)
  smoothing?: number;   // How smooth the frame adjustments should be (0-1)
  onFramingChange?: (transform: string) => void;
  onMovementDetected?: (intensity: number) => void; // Callback when movement is detected
}

export default function AutoFraming({
  videoRef,
  stream,
  enabled = true,
  sensitivity = 0.5,
  smoothing = 0.8,
  onFramingChange,
  onMovementDetected
}: AutoFramingProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const requestIdRef = useRef<number | null>(null);
  const previousFrameRef = useRef<tf.Tensor | null>(null);
  const motionAreasRef = useRef<{ x: number, y: number, weight: number }[]>([]);
  const transformRef = useRef({ x: 0, y: 0, scale: 1 });
  const lastNotificationTimeRef = useRef<number>(0);
  const motionThresholdRef = useRef<number>(5); // Minimum number of motion points to trigger notification
  
  // Create a temporary canvas for processing
  useEffect(() => {
    if (!canvasRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = 320;  // Processing resolution
      canvas.height = 240;
      canvasRef.current = canvas;
    }
    
    // Initialize TensorFlow
    tf.ready().then(() => {
      console.log('TensorFlow.js is ready for auto-framing');
    });
    
    return () => {
      // Clean up
      if (previousFrameRef.current) {
        previousFrameRef.current.dispose();
        previousFrameRef.current = null;
      }
      
      if (requestIdRef.current) {
        cancelAnimationFrame(requestIdRef.current);
        requestIdRef.current = null;
      }
    };
  }, []);
  
  // Start or stop the framing loop based on enabled prop
  useEffect(() => {
    if (enabled && stream && videoRef.current) {
      startFramingLoop();
    } else {
      stopFramingLoop();
      // Reset transform when disabled
      if (!enabled && onFramingChange) {
        transformRef.current = { x: 0, y: 0, scale: 1 };
        onFramingChange('scale(1) translate(0px, 0px)');
      }
    }
    
    return () => {
      stopFramingLoop();
    };
  }, [enabled, stream, videoRef.current]);
  
  const startFramingLoop = () => {
    if (!requestIdRef.current) {
      requestIdRef.current = requestAnimationFrame(framingLoop);
    }
  };
  
  const stopFramingLoop = () => {
    if (requestIdRef.current) {
      cancelAnimationFrame(requestIdRef.current);
      requestIdRef.current = null;
    }
    
    // Clear the previous frame tensor
    if (previousFrameRef.current) {
      previousFrameRef.current.dispose();
      previousFrameRef.current = null;
    }
  };
  
  const framingLoop = () => {
    try {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      if (video && canvas && video.readyState >= 2) {
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        // Draw current video frame to canvas at reduced size for performance
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Get pixel data as tensor
        const currentFrame = tf.browser.fromPixels(canvas).div(255);
        
        // Convert to grayscale for simpler processing
        const grayscale = currentFrame.mean(2).expandDims(2);
        
        // Detect motion if we have a previous frame
        if (previousFrameRef.current) {
          const prevGray = previousFrameRef.current.mean(2).expandDims(2);
          
          // Calculate absolute difference between frames
          const diff = tf.abs(tf.sub(grayscale, prevGray));
          
          // Apply threshold to highlight significant changes
          const threshold = sensitivity * 0.2; // Scale sensitivity appropriately
          const motionMask = diff.greater(tf.scalar(threshold));
          
          // Extract motion data
          const motionData = motionMask.arraySync() as number[][][];
          
          // Clear old motion areas
          motionAreasRef.current = [];
          
          // Sample points from the motion mask (simplified for performance)
          const sampleRate = 10; // Sample every 10 pixels
          for (let y = 0; y < motionData.length; y += sampleRate) {
            for (let x = 0; x < motionData[y].length; x += sampleRate) {
              if (motionData[y][x][0] === 1) { // If motion detected
                motionAreasRef.current.push({
                  x: x / canvas.width,      // Normalize to 0-1
                  y: y / canvas.height,     // Normalize to 0-1
                  weight: 1                  // Equal weight for now
                });
              }
            }
          }
          
          // Calculate framing if motion is detected
          if (motionAreasRef.current.length > 0) {
            calculateFraming();
            
            // Check if we should trigger movement notification
            if (onMovementDetected && 
                motionAreasRef.current.length > motionThresholdRef.current) {
              const now = Date.now();
              // Limit notifications to once per 3 seconds to avoid spamming
              if (now - lastNotificationTimeRef.current > 3000) {
                // Calculate motion intensity (0-100) based on number of motion points
                const maxPoints = (canvas.width * canvas.height) / (sampleRate * sampleRate);
                const intensity = Math.min(100, Math.round((motionAreasRef.current.length / maxPoints) * 100));
                
                // Call the callback with the intensity value
                onMovementDetected(intensity);
                lastNotificationTimeRef.current = now;
              }
            }
          }
          
          // Clean up tensors
          diff.dispose();
          motionMask.dispose();
          prevGray.dispose();
        }
        
        // Store current frame for next comparison
        if (previousFrameRef.current) {
          previousFrameRef.current.dispose();
        }
        previousFrameRef.current = grayscale;
        
        // Clean up tensors
        currentFrame.dispose();
      }
    } catch (error) {
      console.error('Error in auto-framing loop:', error);
    }
    
    // Continue the loop
    requestIdRef.current = requestAnimationFrame(framingLoop);
  };
  
  const calculateFraming = () => {
    // Get motion center of gravity
    let sumX = 0, sumY = 0, totalWeight = 0;
    
    for (const area of motionAreasRef.current) {
      sumX += area.x * area.weight;
      sumY += area.y * area.weight;
      totalWeight += area.weight;
    }
    
    if (totalWeight > 0) {
      const centerX = sumX / totalWeight;
      const centerY = sumY / totalWeight;
      
      // Calculate how much to move (offset from center)
      // Normalize to -0.5 to 0.5 range (center is 0,0)
      const offsetX = 0.5 - centerX;
      const offsetY = 0.5 - centerY;
      
      // Apply smoothing to avoid jittery movement
      const oldTransform = transformRef.current;
      
      // Maximum movement allowed (prevents extreme jumps)
      const maxMovement = 0.15;
      // Scale factor for movement (how much to move relative to the offset)
      const movementScale = 0.2;
      
      // Calculate new transform with smoothing and constraints
      const newX = oldTransform.x + (offsetX * movementScale - oldTransform.x) * (1 - smoothing);
      const newY = oldTransform.y + (offsetY * movementScale - oldTransform.y) * (1 - smoothing);
      
      // Apply constraints to prevent too much movement
      const boundedX = Math.max(-maxMovement, Math.min(maxMovement, newX));
      const boundedY = Math.max(-maxMovement, Math.min(maxMovement, newY));
      
      // Dynamic scaling based on movement (zoom in slightly when stable)
      const targetScale = 1 + (1 - Math.min(1, Math.sqrt(boundedX*boundedX + boundedY*boundedY) * 5)) * 0.1;
      const newScale = oldTransform.scale + (targetScale - oldTransform.scale) * (1 - smoothing);
      
      // Update transform
      transformRef.current = {
        x: boundedX,
        y: boundedY,
        scale: newScale
      };
      
      // Generate CSS transform for the video element
      if (onFramingChange) {
        // Convert to CSS transform (position in % for responsive scaling)
        const translateX = boundedX * 100; // Convert to percentage
        const translateY = boundedY * 100; // Convert to percentage
        const transform = `scale(${newScale}) translate(${translateX}%, ${translateY}%)`;
        onFramingChange(transform);
      }
    }
  };
  
  // The component doesn't render anything visible
  return null;
}