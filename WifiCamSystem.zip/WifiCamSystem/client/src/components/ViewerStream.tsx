import { useRef, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Camera, ImageDown, Fullscreen, MicOff, Mic } from "lucide-react";
import { useLocation } from "wouter";
import StatusIndicator from "./StatusIndicator";
import { useToast } from "@/hooks/use-toast";

interface ViewerStreamProps {
  stream: MediaStream;
  roomId: string;
  onDisconnect: () => void;
}

export default function ViewerStream({ stream, roomId, onDisconnect }: ViewerStreamProps) {
  const [location, setLocation] = useLocation();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const { toast } = useToast();
  const [streamStats, setStreamStats] = useState({
    resolution: "",
    frameRate: 0,
  });
  
  // State for audio mute status
  const [isMuted, setIsMuted] = useState(false);
  
  // Connect stream to video element and ensure audio is enabled
  useEffect(() => {
    if (stream && videoRef.current) {
      console.log('ViewerStream: Connecting stream to video element');
      
      try {
        const videoElement = videoRef.current;
        videoElement.srcObject = stream;
        
        // Check for audio tracks
        const audioTracks = stream.getAudioTracks();
        console.log(`Viewer received stream with ${audioTracks.length} audio tracks`);
        
        // Check for video tracks
        const videoTracks = stream.getVideoTracks();
        console.log(`Viewer received stream with ${videoTracks.length} video tracks`);
        
        if (videoTracks.length === 0) {
          toast({
            title: "No Video Available",
            description: "The camera stream doesn't have any video tracks.",
            variant: "destructive",
          });
        }
        
        // Ensure audio is enabled if available
        if (audioTracks.length > 0) {
          // Enable all audio tracks
          audioTracks.forEach(track => {
            track.enabled = true;
          });
          
          // Make sure browser doesn't mute audio
          videoElement.muted = false;
          
          // Try to autoplay with sound (browsers might block this)
          videoElement.play().catch(error => {
            console.warn('Autoplay with sound failed:', error);
            // Fallback to muted autoplay then unmute after user interaction
            videoElement.muted = true;
            videoElement.play().catch(playError => {
              console.error('Failed to play even with muted audio:', playError);
              toast({
                title: "Playback Error",
                description: "Could not play the stream. Please try refreshing the page.",
                variant: "destructive",
              });
            });
            
            // Show unmute instructions
            toast({
              title: "Audio Muted",
              description: "Click anywhere on the page to unmute audio",
              duration: 5000,
            });
            
            // Add a one-time click handler to unmute
            const unmuteOnClick = () => {
              videoElement.muted = false;
              document.removeEventListener('click', unmuteOnClick);
              
              toast({
                title: "Audio Unmuted",
                description: "You should now be able to hear audio from the stream",
                duration: 3000,
              });
            };
            document.addEventListener('click', unmuteOnClick);
          });
        } else {
          // No audio available, just play the video
          videoElement.play().catch(playError => {
            console.error('Failed to play video stream:', playError);
            toast({
              title: "Playback Error",
              description: "Could not play the video stream. Please try refreshing the page.",
              variant: "destructive",
            });
          });
        }
      } catch (error) {
        console.error('Error connecting stream to video element:', error);
        toast({
          title: "Stream Error",
          description: "There was a problem displaying the camera stream.",
          variant: "destructive",
        });
      }
      
      // Setup video stats monitoring
      const statsInterval = setInterval(() => {
        const video = videoRef.current;
        if (video) {
          // Get resolution from video element
          setStreamStats({
            resolution: `${video.videoWidth}x${video.videoHeight}`,
            frameRate: 0, // We can't reliably get frameRate from HTML element
          });
        }
      }, 1000);
      
      return () => {
        clearInterval(statsInterval);
        // Clean up event listeners here if needed
      };
    }
  }, [stream]);
  
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      videoRef.current?.requestFullscreen().catch(err => {
        console.error(`Error attempting to enable fullscreen: ${err.message}`);
      });
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };
  
  const takeScreenshot = () => {
    const video = videoRef.current;
    if (!video) return;
    
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Create a temporary link to download the image
    const link = document.createElement('a');
    link.download = `wifi-camera-${new Date().toISOString()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-neutral-900 text-white">
      {/* Header */}
      <header className="p-4 flex items-center justify-between border-b border-neutral-800">
        <div className="flex items-center">
          <Button variant="ghost" onClick={() => setLocation('/')} className="mr-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-xl font-medium">Camera Stream</h1>
            <div className="flex items-center text-sm">
              <StatusIndicator status="connected" />
              <span className="ml-2">Room: {roomId}</span>
            </div>
          </div>
        </div>
        
        <Button variant="ghost" onClick={onDisconnect} className="text-red-500">
          Disconnect
        </Button>
      </header>
      
      {/* Main video container */}
      <div className="flex-1 relative bg-black flex items-center justify-center">
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline 
          className="max-h-full max-w-full" 
        />
        
        {/* Stream info overlay */}
        <div className="absolute top-4 right-4 bg-black/60 rounded-lg px-3 py-2">
          <div className="flex items-center text-sm text-green-500">
            <span className="h-2 w-2 rounded-full bg-green-500 mr-1 animate-pulse"></span>
            <span>Live: {streamStats.resolution}</span>
          </div>
        </div>
        
        {/* Camera source info */}
        <div className="absolute bottom-4 left-4 bg-black/60 rounded-lg px-3 py-2">
          <div className="flex items-center text-sm">
            <Camera className="h-4 w-4 mr-1" />
            <span>From: Mobile Camera</span>
          </div>
        </div>
      </div>
      
      {/* Control bar */}
      <div className="bg-neutral-800 p-4 flex justify-center">
        <div className="flex space-x-4">
          <Button 
            variant="ghost" 
            className="rounded-full h-12 w-12 flex items-center justify-center"
            onClick={takeScreenshot}
          >
            <ImageDown className="h-5 w-5" />
          </Button>
          
          <Button 
            variant="ghost" 
            className={`rounded-full h-12 w-12 flex items-center justify-center ${isMuted ? 'bg-red-800/20 text-red-400' : ''}`}
            onClick={() => {
              // Toggle audio mute state
              if (!stream) return;
              
              const audioTracks = stream.getAudioTracks();
              if (audioTracks.length === 0) {
                toast({
                  title: "No Audio Available",
                  description: "This stream doesn't have any audio tracks.",
                  variant: "destructive",
                });
                return;
              }
              
              // Toggle mute state for all audio tracks
              const newMuteState = !isMuted;
              audioTracks.forEach(track => {
                track.enabled = !newMuteState;
              });
              
              // Update state and notify
              setIsMuted(newMuteState);
              
              toast({
                title: newMuteState ? "Audio Muted" : "Audio Unmuted",
                description: newMuteState ? "Stream audio has been muted." : "Stream audio has been unmuted.",
              });
            }}
          >
            {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
          </Button>
          
          <Button 
            variant="ghost"
            className="rounded-full h-12 w-12 flex items-center justify-center"
            onClick={toggleFullscreen}
          >
            <Fullscreen className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
