import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import {
  Eye,
  EyeOff,
  ShieldAlert,
  ShieldCheck,
  Users,
  MoreHorizontal
} from 'lucide-react';
import { ViewerPermission, ViewerInfo } from '@shared/schema';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface ViewerPermissionsProps {
  isHost: boolean;
  viewers: ViewerInfo[];
  onPermissionChange?: (viewerId: string, permission: ViewerPermission) => void;
  onRequestPermission?: () => void;
  currentPermission?: ViewerPermission;
}

export default function ViewerPermissions({
  isHost,
  viewers,
  onPermissionChange,
  onRequestPermission,
  currentPermission = 'view',
}: ViewerPermissionsProps) {
  const [showViewersDialog, setShowViewersDialog] = useState(false);
  const { toast } = useToast();

  const getPermissionBadge = (permission: ViewerPermission) => {
    switch (permission) {
      case 'admin':
        return (
          <Badge variant="default" className="bg-green-500 hover:bg-green-600">
            <ShieldCheck className="w-3 h-3 mr-1" />
            Admin
          </Badge>
        );
      case 'view':
        return (
          <Badge variant="secondary">
            <Eye className="w-3 h-3 mr-1" />
            View
          </Badge>
        );
      case 'blocked':
        return (
          <Badge variant="destructive">
            <EyeOff className="w-3 h-3 mr-1" />
            Blocked
          </Badge>
        );
      default:
        return (
          <Badge variant="outline">Unknown</Badge>
        );
    }
  };

  const handlePermissionChange = (viewerId: string, newPermission: ViewerPermission) => {
    if (onPermissionChange) {
      onPermissionChange(viewerId, newPermission);
      toast({
        title: 'Permission Updated',
        description: `Viewer has been given ${newPermission} permission.`,
      });
    }
  };

  const handleRequestPermission = () => {
    if (onRequestPermission) {
      onRequestPermission();
      toast({
        title: 'Permission Requested',
        description: 'Your request has been sent to the host.',
      });
    }
  };

  // Display for host
  if (isHost) {
    return (
      <>
        <div className="flex items-center gap-2">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowViewersDialog(true)}
              >
                <Users className="w-4 h-4 mr-1" />
                Viewers ({viewers.length})
              </Button>
            </TooltipTrigger>
            <TooltipContent>Manage Viewers</TooltipContent>
          </Tooltip>
        </div>

        <Dialog 
          open={showViewersDialog} 
          onOpenChange={(open) => setShowViewersDialog(open)}
        >
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Manage Viewers</DialogTitle>
              <DialogDescription>
                {viewers.length > 0 
                  ? 'Control permissions for connected viewers.' 
                  : 'No viewers are currently connected.'}
              </DialogDescription>
            </DialogHeader>
            
            {viewers.length > 0 ? (
              <div className="flex flex-col gap-3 max-h-[60vh] overflow-y-auto">
                {viewers.map((viewer) => (
                  <div 
                    key={viewer.id} 
                    className="flex items-center justify-between border rounded-md p-3"
                  >
                    <div className="flex flex-col">
                      <div className="font-medium">
                        {viewer.nickname || viewer.id.substring(0, 8)}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Connected {new Date(viewer.joinedAt).toLocaleTimeString()}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {getPermissionBadge(viewer.permission)}
                      
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="w-4 h-4" />
                            <span className="sr-only">More options</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Change Permission</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem 
                            onClick={() => handlePermissionChange(viewer.id, 'admin')}
                            disabled={viewer.permission === 'admin'}
                          >
                            <ShieldCheck className="w-4 h-4 mr-2 text-green-500" />
                            Make Admin
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handlePermissionChange(viewer.id, 'view')}
                            disabled={viewer.permission === 'view'}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            View Only
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handlePermissionChange(viewer.id, 'blocked')}
                            disabled={viewer.permission === 'blocked'}
                          >
                            <EyeOff className="w-4 h-4 mr-2 text-red-500" />
                            Block Viewer
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-8 text-center text-muted-foreground">
                <Users className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p>Waiting for viewers to connect</p>
              </div>
            )}
            
            <DialogFooter className="sm:justify-end">
              <Button
                type="button"
                variant="secondary"
                onClick={() => setShowViewersDialog(false)}
              >
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </>
    );
  }

  // Display for viewers
  return (
    <div className="flex items-center gap-2">
      {getPermissionBadge(currentPermission)}
      
      {currentPermission === 'view' && (
        <Button
          variant="outline"
          size="sm"
          onClick={handleRequestPermission}
        >
          <ShieldAlert className="w-3 h-3 mr-1" />
          Request Admin
        </Button>
      )}
    </div>
  );
}