import { useEffect, useRef, useState } from "react";
import { Video, Mic, MicOff, Wifi, Focus as FocusIcon, Bell } from "lucide-react";
import StatusIndicator from "./StatusIndicator";
import AutoFraming from "./AutoFraming";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

interface CameraViewProps {
  stream: MediaStream | null;
  isFrontCamera: boolean;
  isLoading: boolean;
  isStreaming: boolean;
  connectionStatus: string;
  roomId: string;
  error?: Error | null;
}

export default function CameraView({
  stream,
  isFrontCamera,
  isLoading,
  isStreaming,
  connectionStatus,
  roomId,
  error
}: CameraViewProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();
  const [hasAudio, setHasAudio] = useState(false);
  const [autoFramingEnabled, setAutoFramingEnabled] = useState(false);
  const [videoTransform, setVideoTransform] = useState('scale(1) translate(0%, 0%)');
  const [movementDetectionEnabled, setMovementDetectionEnabled] = useState(false);
  const [lastMovementTime, setLastMovementTime] = useState<Date | null>(null);
  
  // Connect stream to video element when available and check for audio
  useEffect(() => {
    if (stream && videoRef.current) {
      videoRef.current.srcObject = stream;
      
      // Check if the stream has audio tracks
      const audioTracks = stream.getAudioTracks();
      setHasAudio(audioTracks.length > 0);
      
      console.log(`Camera stream has ${audioTracks.length} audio tracks`);
      if (audioTracks.length > 0) {
        console.log(`Audio track enabled: ${audioTracks[0].enabled}`);
        console.log(`Audio track label: ${audioTracks[0].label}`);
      }
    } else {
      setHasAudio(false);
    }
  }, [stream]);
  
  // Handle movement detection
  const handleMovementDetected = (intensity: number) => {
    if (!movementDetectionEnabled) return;
    
    console.log(`Movement detected with intensity: ${intensity}%`);
    
    // Update the last movement time
    setLastMovementTime(new Date());
    
    // Show toast notification with movement intensity
    toast({
      title: `Movement Detected!`,
      description: `Movement intensity: ${intensity}%`,
      variant: "destructive",
    });
    
    // Play a beep sound alert
    try {
      // Check if AudioContext is available in this browser
      if (typeof window === 'undefined' || 
          (!(window as any).AudioContext && !(window as any).webkitAudioContext)) {
        console.warn('Web Audio API not supported in this browser');
        return;
      }
      
      // Create an audio context
      const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
      const audioContext = new AudioContextClass();
      
      // Resume audio context if it's suspended (required by some browsers)
      if (audioContext.state === 'suspended') {
        audioContext.resume();
      }
      
      // Create an oscillator (beep sound generator)
      const oscillator = audioContext.createOscillator();
      oscillator.type = 'sine'; // Sine wave - a pure tone
      oscillator.frequency.setValueAtTime(880, audioContext.currentTime); // A5 note - 880Hz
      
      // Create a gain node to control volume
      const gainNode = audioContext.createGain();
      gainNode.gain.setValueAtTime(0.2, audioContext.currentTime); // 20% volume
      
      // Connect oscillator to gain node and gain node to audio output
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      // Start and stop the beep (short duration)
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.2); // 200ms beep
      
      // Schedule a second beep for an alarm-like sound
      const oscillator2 = audioContext.createOscillator();
      oscillator2.type = 'sine';
      oscillator2.frequency.setValueAtTime(988, audioContext.currentTime + 0.3); // B5 note - 988Hz
      oscillator2.connect(gainNode);
      
      oscillator2.start(audioContext.currentTime + 0.3);
      oscillator2.stop(audioContext.currentTime + 0.5);
      
      // Close the audio context after a short delay to clean up resources
      setTimeout(() => {
        audioContext.close().catch((e: Error) => console.warn('Error closing audio context:', e));
      }, 1000);
    } catch (err) {
      console.error('Error playing alert sound:', err);
    }
  };
  
  // Get the current host URL for sharing
  const connectionUrl = `${window.location.origin}/viewer/${roomId}`;
  
  return (
    <div className="camera-container flex-grow relative flex items-center justify-center bg-black">
      <video 
        ref={videoRef}
        autoPlay 
        playsInline 
        className={`absolute inset-0 w-full h-full object-cover ${isFrontCamera ? 'scale-x-[-1]' : ''}`}
        style={{ transform: videoTransform, transition: 'transform 0.5s ease' }}
        muted
      />
      
      {/* Auto-framing component (invisible) */}
      {isStreaming && <AutoFraming 
        videoRef={videoRef}
        stream={stream}
        enabled={autoFramingEnabled || movementDetectionEnabled}
        sensitivity={0.6}
        smoothing={0.85}
        onFramingChange={setVideoTransform}
        onMovementDetected={handleMovementDetected}
      />}
      
      {/* Camera status overlay when not streaming */}
      {!isStreaming && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70">
          <div className="text-center mb-8">
            <Video className="h-16 w-16 text-primary animate-pulse" />
            <p className="mt-4 text-xl">Camera Ready</p>
            <p className="text-neutral-400 mt-2">Tap the start button to begin streaming</p>
          </div>
        </div>
      )}
      
      {/* Loading overlay */}
      {isLoading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70">
          <div className="text-center mb-8">
            <div className="h-16 w-16 rounded-full border-4 border-primary border-t-transparent animate-spin" />
            <p className="mt-4 text-xl">Loading Camera</p>
            <p className="text-neutral-400 mt-2">Please grant camera permissions</p>
          </div>
        </div>
      )}
      
      {/* Error overlay */}
      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70">
          <div className="text-center mb-8">
            <div className="h-16 w-16 text-red-500 flex items-center justify-center">
              <span className="material-icons text-5xl">error</span>
            </div>
            <p className="mt-4 text-xl text-red-500">Camera Error</p>
            <p className="text-neutral-400 mt-2">{error.message}</p>
          </div>
        </div>
      )}
      
      {/* Stream info overlay when streaming */}
      {isStreaming && (
        <div className="absolute top-4 right-4 bg-black/60 rounded-lg px-3 py-2">
          <div className="flex flex-col gap-1">
            <div className="flex items-center text-sm text-green-500">
              <span className="h-2 w-2 rounded-full bg-green-500 mr-1 animate-pulse"></span>
              <span>Live</span>
            </div>
            <div className="flex items-center text-sm">
              {hasAudio ? (
                <div className="flex items-center text-green-400">
                  <Mic className="h-3 w-3 mr-1" />
                  <span>Audio On</span>
                </div>
              ) : (
                <div className="flex items-center text-yellow-400">
                  <MicOff className="h-3 w-3 mr-1" />
                  <span>No Audio</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
      {/* Connection info overlay */}
      <div className="absolute bottom-24 left-4 bg-black/60 rounded-lg px-3 py-2">
        <p className="text-sm font-medium">Connect at:</p>
        <p className="text-primary font-medium break-all">{connectionUrl}</p>
      </div>
      
      {/* Camera controls */}
      {isStreaming && (
        <div className="absolute bottom-4 right-4 bg-black/60 rounded-lg px-3 py-2">
          <div className="flex flex-col space-y-2">
            {/* Auto-framing control */}
            <div className="flex items-center space-x-2">
              <FocusIcon className={`h-4 w-4 ${autoFramingEnabled ? 'text-primary' : 'text-gray-400'}`} />
              <Label htmlFor="auto-framing" className="text-sm font-medium">
                Smart Framing
              </Label>
              <Switch
                id="auto-framing"
                checked={autoFramingEnabled}
                onCheckedChange={setAutoFramingEnabled}
                className="data-[state=checked]:bg-primary"
              />
            </div>
            
            {/* Movement detection control */}
            <div className="flex items-center space-x-2">
              <Bell className={`h-4 w-4 ${movementDetectionEnabled ? 'text-primary' : 'text-gray-400'}`} />
              <Label htmlFor="movement-detection" className="text-sm font-medium">
                Movement Alerts
              </Label>
              <Switch
                id="movement-detection"
                checked={movementDetectionEnabled}
                onCheckedChange={setMovementDetectionEnabled}
                className="data-[state=checked]:bg-primary"
              />
            </div>
            
            {/* Movement detection status */}
            {movementDetectionEnabled && lastMovementTime && (
              <div className="mt-1 text-xs text-gray-300">
                Last movement: {lastMovementTime.toLocaleTimeString()}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
