import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Camera, Monitor, Wifi } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { toast } = useToast();
  
  // Generate a random room ID
  const generateRoomId = () => {
    return Math.random().toString(36).substring(2, 10);
  };

  const newRoomId = generateRoomId();
  
  return (
    <div className="min-h-screen bg-neutral-900 text-white flex flex-col">
      <header className="p-6 flex items-center justify-center border-b border-neutral-800">
        <div className="flex items-center gap-2">
          <Wifi className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-medium">WiFi Camera</h1>
        </div>
      </header>
      
      <main className="flex-1 container mx-auto px-4 py-8 flex flex-col items-center justify-center">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">Turn your phone into a WiFi camera</h2>
            <p className="text-neutral-400">Stream your camera to any device on the same network</p>
          </div>
          
          <div className="grid gap-6">
            <Card className="bg-neutral-800 border-neutral-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="h-5 w-5 text-primary" />
                  Start Camera
                </CardTitle>
                <CardDescription className="text-neutral-400">
                  Use your device as a WiFi camera
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-neutral-300">
                  Create a new camera stream that others can watch from any browser
                  on the same network.
                </p>
              </CardContent>
              <CardFooter>
                <Link href={`/camera/${newRoomId}`} className="w-full">
                  <Button size="lg" className="w-full bg-primary hover:bg-primary/90">
                    Start Camera
                  </Button>
                </Link>
              </CardFooter>
            </Card>
            
            <Card className="bg-neutral-800 border-neutral-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Monitor className="h-5 w-5 text-green-500" />
                  View Camera
                </CardTitle>
                <CardDescription className="text-neutral-400">
                  Watch a camera stream from another device
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-neutral-300">
                  Enter a room ID to connect to an existing camera stream
                  from another device on your network.
                </p>
              </CardContent>
              <CardFooter>
                <Link href={`/viewer`} className="w-full">
                  <Button size="lg" variant="outline" className="w-full border-neutral-700 hover:bg-neutral-700">
                    Connect to Camera
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>
      
      <footer className="p-4 text-center text-neutral-500 text-sm">
        <p>All devices must be on the same WiFi network</p>
      </footer>
    </div>
  );
}
