import { useState, useEffect, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { useWebSocket } from "@/hooks/use-websocket";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import ViewerStream from "@/components/ViewerStream";
import { Monitor, ArrowLeft, Tv } from "lucide-react";
import StatusIndicator from "@/components/StatusIndicator";

export default function Viewer() {
  const { roomId: paramRoomId } = useParams();
  const [location, setLocation] = useLocation();
  const [roomId, setRoomId] = useState(paramRoomId || "");
  const [inputRoomId, setInputRoomId] = useState("");
  const [connected, setConnected] = useState(false);
  const [peerConnection, setPeerConnection] = useState<RTCPeerConnection | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const viewerId = useRef(`viewer-${Date.now()}`).current;
  
  // WebSocket for signaling
  const {
    connect: connectWs,
    disconnect: disconnectWs,
    connected: wsConnected,
    error: wsError,
    sendMessage,
    lastMessage
  } = useWebSocket();
  
  // Connect to room if roomId is provided in URL
  useEffect(() => {
    if (paramRoomId) {
      setRoomId(paramRoomId);
      joinRoom(paramRoomId);
    }
  }, [paramRoomId]);
  
  const joinRoom = (id: string) => {
    if (!id.trim()) return;
    
    console.log(`Attempting to join room: ${id} as viewer: ${viewerId}`);
    
    // Update the URL
    if (location !== `/viewer/${id}`) {
      setLocation(`/viewer/${id}`);
    }
    
    setRoomId(id);
    
    // Connect to WebSocket
    try {
      console.log('Connecting to WebSocket server...');
      connectWs();
    } catch (wsError) {
      console.error('Error connecting to WebSocket:', wsError);
    }
    
    try {
      console.log('Creating WebRTC peer connection...');
      
      // Create WebRTC peer connection with improved ice servers configuration
      const pc = new RTCPeerConnection({
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun1.l.google.com:19302' },
          { urls: 'stun2.l.google.com:19302' },
          { urls: 'stun3.l.google.com:19302' },
          { urls: 'stun4.l.google.com:19302' },
        ],
        iceCandidatePoolSize: 10 // Increase candidates pool size for better connectivity
      });
      
      // Log connection state changes for debugging
      pc.onconnectionstatechange = () => {
        console.log('WebRTC connection state changed:', pc.connectionState);
        
        // Handle failed connection state
        if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
          console.error('WebRTC connection failed or disconnected');
          // You can add additional handling here like automatic reconnection
        }
      };
      
      pc.oniceconnectionstatechange = () => {
        console.log('ICE connection state changed:', pc.iceConnectionState);
        
        // Handle failed ICE connection state
        if (pc.iceConnectionState === 'failed' || pc.iceConnectionState === 'disconnected') {
          console.error('ICE connection failed or disconnected');
          // You can add additional handling here
        }
      };
      
      // Set up event handlers with improved error handling
      pc.onicecandidate = (event) => {
        if (event.candidate && wsConnected && hostIdRef.current) {
          try {
            console.log(`Sending ICE candidate to host: ${hostIdRef.current}`);
            sendMessage({
              type: 'ice-candidate',
              roomId: id,
              senderId: viewerId,
              receiverId: hostIdRef.current,
              data: event.candidate
            });
          } catch (error) {
            console.error('Error sending ICE candidate:', error);
          }
        } else if (event.candidate) {
          console.log('ICE candidate generated but cannot send yet:', event.candidate);
          // Store candidates to send later when host is identified
        }
      };
      
      // Handle tracks coming from the host
      pc.ontrack = (event) => {
        console.log('Track received from host:', event.track.kind);
        
        // Ensure we only set the stream once to avoid issues
        if (event.streams && event.streams[0]) {
          console.log('Setting remote stream with tracks:', 
            event.streams[0].getTracks().map(t => `${t.kind}: ${t.id}`).join(', '));
          
          setStream(event.streams[0]);
        } else {
          console.warn('Received track event with no streams');
        }
      };
      
      setPeerConnection(pc);
      
      // Schedule a delayed check to see if we've received any tracks
      setTimeout(() => {
        if (isMounted.current && pc.connectionState === 'connected' && !stream) {
          console.warn('Connected but no stream received after timeout');
          // Could implement additional recovery logic here
        }
      }, 10000);
      
    } catch (rtcError) {
      console.error('Error creating WebRTC peer connection:', rtcError);
    }
    
    // No need to send join message here - we'll do it when we receive welcome message
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    joinRoom(inputRoomId);
  };
  
  const disconnect = () => {
    if (peerConnection) {
      peerConnection.close();
      setPeerConnection(null);
    }
    
    if (wsConnected) {
      sendMessage({
        type: 'leave',
        roomId,
        senderId: viewerId
      });
      disconnectWs();
    }
    
    setConnected(false);
    setStream(null);
    setLocation('/viewer');
    setRoomId("");
  };
  
  // Reference to store host ID (outside of joinRoom)
  const hostIdRef = useRef<string | null>(null);
  
  // Store ICE candidates that arrive before remote description is set
  const pendingIceCandidates = useRef<RTCIceCandidateInit[]>([]);
  
  // Handle incoming WebSocket messages with proper typing
  useEffect(() => {
    // This check ensures the dependencies are defined
    if (!lastMessage || !peerConnection) return;
    
    // Process the WebSocket message
    const processMessage = async () => {
      try {
        const data = JSON.parse(lastMessage);
        
        switch(data.type) {
          case 'welcome':
            console.log('Received welcome message:', data.message);
            
            // When we receive the welcome message, attempt to join the room with retry mechanism
            try {
              console.log(`Attempting to join room ${roomId} as viewer ${viewerId}`);
              
              // Try to send join message immediately
              const success = sendMessage({
                type: 'join',
                roomId,
                senderId: viewerId
              });
              
              // If immediate send fails, retry with slight delay
              if (!success) {
                console.log('Immediate join message send failed, scheduling retry...');
                setTimeout(() => {
                  if (isMounted.current) {
                    console.log('Retrying join message send...');
                    sendMessage({
                      type: 'join',
                      roomId,
                      senderId: viewerId
                    });
                  }
                }, 500);
              }
            } catch (joinError) {
              console.error('Error sending join message after welcome:', joinError);
            }
            break;
            
          case 'offer':
            // Handle offer from camera host
            // Save the host ID for later use
            hostIdRef.current = data.senderId;
            console.log('Saved host ID:', hostIdRef.current);
            
            // Handle offer with better error handling and logging
            try {
              console.log('Setting remote description from offer:', data.data.type);
              
              // Enhanced process with more logging
              await peerConnection.setRemoteDescription(new RTCSessionDescription(data.data));
              console.log('Remote description set successfully, creating answer...');
              
              // Process any pending ICE candidates now that we have the remote description
              if (pendingIceCandidates.current.length > 0) {
                console.log(`Processing ${pendingIceCandidates.current.length} pending ICE candidates`);
                for (const candidate of pendingIceCandidates.current) {
                  try {
                    await peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
                  } catch (pendingIceError) {
                    console.error('Error adding pending ICE candidate:', pendingIceError);
                  }
                }
                pendingIceCandidates.current = [];
              }
              
              const answer = await peerConnection.createAnswer();
              console.log('Answer created:', answer.type);
              
              await peerConnection.setLocalDescription(answer);
              console.log('Local description (answer) set successfully');
              
              // Send the answer to the camera
              console.log('Sending answer to camera:', hostIdRef.current);
              const messageSent = sendMessage({
                type: 'answer',
                roomId,
                senderId: viewerId,
                receiverId: data.senderId,
                data: peerConnection.localDescription
              });
              
              if (messageSent) {
                console.log('Answer sent successfully');
                setConnected(true);
              } else {
                console.error('Failed to send answer, will retry');
                
                // Retry after a short delay
                setTimeout(() => {
                  if (isMounted.current && peerConnection.localDescription) {
                    console.log('Retrying answer send...');
                    sendMessage({
                      type: 'answer',
                      roomId,
                      senderId: viewerId,
                      receiverId: data.senderId,
                      data: peerConnection.localDescription
                    });
                  }
                }, 500);
              }
            } catch (offerError) {
              console.error('Error handling offer:', offerError);
            }
            break;
            
          case 'joined':
            // Successfully joined room
            console.log(`Successfully joined room: ${data.roomId} as viewer`);
            
            if (data.clients && data.clients.length > 0) {
              // Find host in the client list
              const host = data.clients.find((client: any) => client.isHost);
              if (host) {
                console.log(`Found host in room: ${host.id}`);
                hostIdRef.current = host.id;
              }
            } else {
              console.log('No other clients in room yet');
            }
            break;
            
          case 'ice-candidate':
            // Add ICE candidate with improved handling
            console.log('Received ICE candidate from host');
            
            try {
              // Check if the remote description has been set
              if (peerConnection.remoteDescription && peerConnection.remoteDescription.type) {
                console.log('Adding ICE candidate immediately');
                await peerConnection.addIceCandidate(new RTCIceCandidate(data.data));
                console.log('ICE candidate added successfully');
              } else {
                // Buffer the candidate if remote description is not set yet
                console.log('Remote description not set, buffering ICE candidate');
                pendingIceCandidates.current.push(data.data);
              }
            } catch (iceError) {
              console.error('Error processing ICE candidate:', iceError);
            }
            break;
        }
      } catch (err) {
        console.error('Error parsing WebSocket message:', err);
      }
    };
    
    // Call the async function
    processMessage();
  }, [lastMessage, peerConnection, roomId, viewerId, sendMessage]);
  
  // Reference to track if component is mounted
  const isMounted = useRef(true);
  
  // Clean up on unmount
  useEffect(() => {
    // Set mounted flag
    isMounted.current = true;
    
    return () => {
      // Mark as unmounted to prevent state updates after unmount
      isMounted.current = false;
      
      // Clean up WebRTC connection
      if (peerConnection) {
        try {
          // Only attempt to close if not already closing or closed
          if (peerConnection.connectionState !== 'closed') {
            peerConnection.close();
          }
        } catch (peerError) {
          console.error('Error closing peer connection:', peerError);
        }
      }
      
      // Clean up WebSocket
      if (wsConnected) {
        try {
          disconnectWs();
        } catch (wsError) {
          console.error('Error disconnecting WebSocket:', wsError);
        }
      }
    };
  }, []);
  
  // If we have a roomId but not connected yet
  if (roomId && !connected && !stream) {
    return (
      <div className="min-h-screen bg-neutral-900 text-white flex flex-col">
        <header className="p-4 flex items-center border-b border-neutral-800">
          <Button variant="ghost" onClick={() => setLocation('/')} className="mr-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-medium">Connect to Camera</h1>
        </header>
        
        <main className="flex-1 flex flex-col items-center justify-center p-4">
          <Card className="w-full max-w-md bg-neutral-800 border-neutral-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Tv className="h-5 w-5 text-primary" />
                Connecting to Camera
              </CardTitle>
              <CardDescription className="text-neutral-400">
                Room ID: {roomId}
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center py-8">
              <div className="flex flex-col items-center">
                <StatusIndicator status="connecting" />
                <p className="mt-4 text-lg">Waiting for camera...</p>
                <p className="text-sm text-neutral-500 mt-2">Make sure the camera is streaming</p>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={disconnect}>
                Cancel
              </Button>
            </CardFooter>
          </Card>
        </main>
      </div>
    );
  }
  
  // If we're connected and have a stream
  if (connected && stream) {
    return (
      <ViewerStream 
        stream={stream} 
        roomId={roomId} 
        onDisconnect={disconnect} 
      />
    );
  }
  
  // Initial connect screen
  return (
    <div className="min-h-screen bg-neutral-900 text-white flex flex-col">
      <header className="p-4 flex items-center border-b border-neutral-800">
        <Button variant="ghost" onClick={() => setLocation('/')} className="mr-2">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-medium">Connect to Camera</h1>
      </header>
      
      <main className="flex-1 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md bg-neutral-800 border-neutral-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Monitor className="h-5 w-5 text-primary" />
              Connect to Camera
            </CardTitle>
            <CardDescription className="text-neutral-400">
              Enter the Room ID from the camera device
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Input
                  type="text"
                  placeholder="Enter Room ID"
                  value={inputRoomId}
                  onChange={(e) => setInputRoomId(e.target.value)}
                  className="bg-neutral-900 border-neutral-700"
                />
              </div>
            </form>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full bg-primary hover:bg-primary/90" 
              onClick={() => joinRoom(inputRoomId)}
              disabled={!inputRoomId.trim()}
            >
              Connect
            </Button>
          </CardFooter>
        </Card>
      </main>
    </div>
  );
}
