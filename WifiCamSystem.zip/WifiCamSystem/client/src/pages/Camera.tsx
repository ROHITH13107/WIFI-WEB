import { useEffect, useState, useRef } from "react";
import { useParams } from "wouter";
import CameraView from "@/components/CameraView";
import CameraControls from "@/components/CameraControls";
import Header from "@/components/Header";
import SettingsPanel from "@/components/SettingsPanel";
import RecordingControl from "@/components/RecordingControl";
import ViewerPermissions from "@/components/ViewerPermissions";
import { useCamera } from "@/hooks/use-camera";
import { useWebRTC } from "@/hooks/use-webrtc";
import { useBattery } from "@/hooks/use-battery";
import { useWebSocket } from "@/hooks/use-websocket";
import { AppSettings, defaultSettings, RecordingState, ViewerInfo, ViewerPermission } from "@shared/schema";

export default function Camera() {
  const { roomId = "" } = useParams();
  const [isStreaming, setIsStreaming] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [viewerCount, setViewerCount] = useState(0);
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);
  const [hostId, setHostId] = useState<string>("");
  
  // State for recording functionality
  const [recordingState, setRecordingState] = useState<RecordingState>({
    isRecording: false
  });
  
  // State for viewer permissions management
  const [viewers, setViewers] = useState<ViewerInfo[]>([]);
  
  // Get the camera stream
  const { 
    stream, 
    isFrontCamera, 
    toggleCamera, 
    error: cameraError,
    isLoading: cameraLoading,
    requestPermissions
  } = useCamera(settings.camera);
  
  // Battery status
  const { batteryLevel, isCharging, error: batteryError } = useBattery();
  
  // WebSocket for signaling
  const {
    connect,
    disconnect,
    connected,
    error: socketError,
    sendMessage,
    lastMessage
  } = useWebSocket();
  
  // WebRTC connection management
  const {
    createOffer,
    processAnswer,
    addIceCandidate,
    connections,
    connectionState,
    error: rtcError
  } = useWebRTC(stream, settings.connection);
  
  // Reference to track if the component is mounted
  const isMounted = useRef(true);
  
  // Reference to store current intervals for cleanup
  const joinIntervalRef = useRef<number | null>(null);
  
  useEffect(() => {
    // Set mount state
    isMounted.current = true;
    
    // Generate a stable client ID for this session
    const generatedHostId = `host-${Date.now()}`;
    setHostId(generatedHostId);
    
    // Connect to WebSocket server
    if (roomId) {
      console.log('Connecting to WebSocket server as host with ID:', generatedHostId);
      console.log('Current URL:', window.location.href);
      console.log('WebSocket URL should be:', `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.host}/ws`);
      
      // Clear any existing interval
      if (joinIntervalRef.current) {
        clearInterval(joinIntervalRef.current);
        joinIntervalRef.current = null;
      }
      
      // Connect to WebSocket
      try {
        connect();
      } catch (error) {
        console.error('Error connecting to WebSocket:', error);
      }
      
      // Add a safety timeout to reconnect if necessary
      const reconnectTimeout = setTimeout(() => {
        if (!connected && isMounted.current) {
          console.log('No WebSocket connection after timeout, attempting to reconnect...');
          try {
            connect();
          } catch (reconnectError) {
            console.error('Error during reconnect:', reconnectError);
          }
        }
      }, 3000);
      
      // Cleanup timeout on unmount
      return () => {
        clearTimeout(reconnectTimeout);
      };
    }
    
    // Cleanup when component unmounts
    return () => {
      // Mark component as unmounted
      isMounted.current = false;
      
      // Clear any pending intervals
      if (joinIntervalRef.current) {
        clearInterval(joinIntervalRef.current);
        joinIntervalRef.current = null;
      }
    };
  }, [roomId, connect]);
  
  // Send leave message and disconnect when component unmounts
  useEffect(() => {
    return () => {
      if (connected && roomId && hostId) {
        console.log('Disconnecting from room:', roomId);
        try {
          sendMessage({
            type: 'leave',
            roomId,
            senderId: hostId
          });
        } catch (error) {
          console.error('Error sending leave message:', error);
        }
        
        try {
          disconnect();
        } catch (error) {
          console.error('Error disconnecting WebSocket:', error);
        }
      }
    };
  }, [connected, disconnect, hostId, roomId, sendMessage]);
  
  // Handle recording state changes
  const handleRecordingStateChange = (newState: RecordingState) => {
    setRecordingState(newState);
    
    // Broadcast recording state to viewers if we're connected
    if (connected && roomId) {
      try {
        sendMessage({
          type: 'recording-state',
          roomId,
          senderId: hostId,
          data: newState
        });
      } catch (error) {
        console.error('Error broadcasting recording state:', error);
      }
    }
  };
  
  // Handle viewer permission changes
  const handlePermissionChange = (viewerId: string, permission: ViewerPermission) => {
    // Update local state
    setViewers(prev => 
      prev.map(viewer => 
        viewer.id === viewerId 
          ? { ...viewer, permission } 
          : viewer
      )
    );
    
    // Send permission update to the server/viewer
    if (connected && roomId) {
      sendMessage({
        type: 'permission-response',
        roomId,
        senderId: hostId,
        receiverId: viewerId,
        data: { permission }
      });
    }
  };

  // Handle incoming WebSocket messages
  useEffect(() => {
    if (!lastMessage || !hostId) return;
    
    // Make sure we're not trying to handle messages after component unmounts
    if (!isMounted.current) return;
    
    const handleMessage = async () => {
      try {
        let data;
        try {
          data = JSON.parse(lastMessage);
          console.log('Parsed WebSocket message:', data);
        } catch (parseError) {
          console.error('Failed to parse WebSocket message:', parseError);
          return;
        }
        
        if (!data || !data.type) {
          console.warn('Received message with invalid format:', lastMessage);
          return;
        }
        
        console.log('Processing WebSocket message:', data.type);
        
        // Handle the welcome message immediately to improve reliability
        if (data.type === 'welcome') {
          console.log('Received welcome message:', data.message);
          
          // When we receive the welcome message, attempt to join the room immediately
          try {
            console.log(`Attempting to join room ${roomId} as host ${hostId}`);
            
            // First immediate attempt
            if (connected) {
              console.log('Sending immediate join message...');
              sendMessage({
                type: 'join',
                roomId,
                senderId: hostId
              });
              
              // CRITICAL: Always schedule a delayed retry regardless of immediate success
              // This dramatically improves reliability in Replit's environment
              console.log('Scheduling multiple join retries for improved reliability...');
              
              // First retry
              setTimeout(() => {
                if (isMounted.current && connected) {
                  console.log('First delayed join attempt...');
                  sendMessage({
                    type: 'join',
                    roomId,
                    senderId: hostId
                  });
                }
              }, 500);
              
              // Second retry with longer delay
              setTimeout(() => {
                if (isMounted.current && connected) {
                  console.log('Second delayed join attempt...');
                  sendMessage({
                    type: 'join',
                    roomId,
                    senderId: hostId
                  });
                }
              }, 1500);
            }
          } catch (joinError) {
            console.error('Error sending join message after welcome:', joinError);
          }
          return; // Skip further processing for welcome message
        }
        
        switch(data.type) {
          case 'viewer-joined':
            // New viewer joined, create and send offer
            console.log(`Viewer joined room: ${data.clientId}`);
            if (stream) {
              try {
                console.log(`Creating offer for viewer: ${data.clientId}`);
                const offer = await createOffer(data.clientId, stream);
                if (offer && isMounted.current) {
                  try {
                    console.log(`Sending WebRTC offer to viewer: ${data.clientId}`);
                    sendMessage({
                      type: 'offer',
                      roomId,
                      senderId: hostId,
                      receiverId: data.clientId,
                      data: offer
                    });
                  } catch (sendError) {
                    console.error('Error sending offer:', sendError);
                  }
                }
              } catch (offerError) {
                console.error('Error creating offer:', offerError);
              }
            } else {
              console.warn('Cannot create offer: No media stream available');
            }
            
            // Update viewer count and add to viewers list
            if (isMounted.current) {
              setViewerCount(prev => prev + 1);
              
              // Add the new viewer to our viewers array with default 'view' permission
              setViewers(prev => [
                ...prev, 
                {
                  id: data.clientId,
                  permission: 'view',
                  nickname: data.nickname,
                  joinedAt: Date.now()
                }
              ]);
            }
            break;
            
          case 'joined':
            // Successful room join
            console.log(`Successfully joined room: ${data.roomId} as ${data.isHost ? 'host' : 'viewer'}`);
            console.log(`Other clients in room: ${data.clients?.length || 0}`);
            
            // Connection is fully established, stop retry mechanisms
            if (joinIntervalRef.current) {
              clearInterval(joinIntervalRef.current);
              joinIntervalRef.current = null;
            }
            
            break;
            
          case 'answer':
            // Handle answer from viewer
            console.log('Got answer from viewer:', data.senderId);
            if (data.data && isMounted.current) {
              try {
                console.log(`Processing answer from viewer: ${data.senderId}`);
                const result = await processAnswer(data.senderId, data.data);
                console.log('Process answer result:', result);
              } catch (answerError) {
                console.error('Error processing answer:', answerError);
              }
            }
            break;
            
          case 'ice-candidate':
            // Add ICE candidate
            if (data.data && isMounted.current) {
              try {
                console.log(`Received ICE candidate from: ${data.senderId}`);
                await addIceCandidate(data.senderId, data.data);
              } catch (iceError) {
                console.error('Error adding ICE candidate:', iceError);
              }
            }
            break;
            
          case 'client-left':
            // Viewer left
            console.log(`Client left the room: ${data.clientId}`);
            if (isMounted.current) {
              setViewerCount(prev => Math.max(0, prev - 1));
              
              // Remove viewer from the list
              setViewers(prev => prev.filter(viewer => viewer.id !== data.clientId));
            }
            break;
            
          case 'permission-request':
            // Handle permission request from viewer
            console.log(`Permission request from: ${data.senderId}`);
            if (isMounted.current) {
              // Add to UI notification or update existing viewer permission
              const viewerExists = viewers.some(viewer => viewer.id === data.senderId);
              
              if (viewerExists) {
                // If the viewer exists, show their request (in a real app, this might trigger a notification)
                console.log(`Viewer ${data.senderId} requested admin permission`);
              }
            }
            break;
            
          case 'recording-state':
            // Handle recording state update from host (as a viewer would)
            console.log(`Recording state update: ${data.data?.isRecording ? 'Started' : 'Stopped'}`);
            if (isMounted.current && data.data) {
              setRecordingState(data.data);
            }
            break;
            
          // Welcome case is handled earlier, outside the switch
          // This is kept for compatibility but should never execute
            
          default:
            console.log('Unhandled message type:', data.type);
        }
      } catch (err) {
        console.error('Error handling WebSocket message:', err);
      }
    };
    
    // Use a try/catch to prevent unhandled promise rejections
    try {
      handleMessage().catch(error => {
        console.error('Unhandled promise rejection in message handler:', error);
      });
    } catch (error) {
      console.error('Error initiating message handling:', error);
    }
  }, [lastMessage, roomId, hostId, stream, createOffer, processAnswer, addIceCandidate, sendMessage, viewers, connected]);
  
  const handleStartStreaming = () => {
    requestPermissions();
    setIsStreaming(true);
  };
  
  const handleStopStreaming = () => {
    setIsStreaming(false);
  };
  
  const connectionStatus = connected ? 'connected' : socketError ? 'error' : 'connecting';
  
  const error = cameraError || socketError || rtcError || batteryError;
  
  useEffect(() => {
    // Keep screen on if setting is enabled
    if (settings.system.keepScreenOn) {
      const wakeLock = async () => {
        try {
          // @ts-ignore - wakeLock may not be available on all browsers
          if ('wakeLock' in navigator) {
            // @ts-ignore
            await navigator.wakeLock.request('screen');
          }
        } catch (err) {
          console.error('Wake Lock error:', err);
        }
      };
      
      if (isStreaming) {
        wakeLock();
      }
    }
  }, [isStreaming, settings.system.keepScreenOn]);
  
  return (
    <div className="flex flex-col h-screen w-screen relative bg-black">
      <Header 
        connectionStatus={connectionStatus} 
        batteryLevel={batteryLevel} 
        isCharging={isCharging} 
        viewerCount={viewerCount} 
      />
      
      <div className="absolute top-16 left-0 right-0 z-10 flex justify-between px-4 py-2 bg-black/40">
        <RecordingControl 
          stream={stream}
          isHost={true}
          recordingState={recordingState}
          onRecordingStateChange={handleRecordingStateChange}
        />
        
        <ViewerPermissions 
          isHost={true}
          viewers={viewers}
          onPermissionChange={handlePermissionChange}
        />
      </div>
      
      <CameraView 
        stream={stream} 
        isFrontCamera={isFrontCamera} 
        isLoading={cameraLoading}
        isStreaming={isStreaming}
        connectionStatus={connectionStatus}
        roomId={roomId}
        error={error}
      />
      
      <CameraControls 
        isStreaming={isStreaming} 
        onStartStreaming={handleStartStreaming} 
        onStopStreaming={handleStopStreaming} 
        onToggleCamera={toggleCamera}
        onToggleSettings={() => setSettingsOpen(true)}
      />
      
      <SettingsPanel 
        open={settingsOpen} 
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        onSettingsChange={setSettings}
        roomId={roomId}
      />
    </div>
  );
}