// WebRTC helper functions
import { ConnectionSettings, CameraSettings, SystemSettings } from '@shared/schema';

// Configure a peer connection with standard options
export function configurePeerConnection(settings?: ConnectionSettings): RTCPeerConnection {
  // Default settings if none provided
  const config: RTCConfiguration = {
    iceServers: [],
    iceTransportPolicy: 'all',
    iceCandidatePoolSize: 10
  };
  
  // Add STUN servers if enabled (make sure iceServers is initialized)
  if (!config.iceServers) {
    config.iceServers = [];
  }
  
  if (!settings || settings.useStunServers) {
    const stunServers: RTCIceServer[] = [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun2.l.google.com:19302' },
      { urls: 'stun:stun3.l.google.com:19302' },
      { urls: 'stun:stun4.l.google.com:19302' }
    ];
    config.iceServers = [...config.iceServers, ...stunServers];
  }
  
  // Add TURN servers if enabled
  if (settings?.useTurnServers) {
    // Note: In a real application, you would use your own TURN server
    // This is just an example using a public free TURN server
    if (config.iceServers) {
      config.iceServers.push({
        urls: 'turn:openrelay.metered.ca:80',
        username: 'openrelayproject',
        credential: 'openrelayproject'
      });
    }
  }
  
  // Set ICE transport policy
  if (settings?.iceTransportPolicy) {
    config.iceTransportPolicy = settings.iceTransportPolicy;
  }
  
  // Create and return the RTCPeerConnection
  const pc = new RTCPeerConnection(config);
  
  return pc;
}

// Get optimal video constraints based on camera settings and system settings
export function getVideoConstraints(
  cameraSettings: CameraSettings, 
  systemSettings: SystemSettings,
  facingMode: 'user' | 'environment' = 'user'
): MediaTrackConstraints {
  
  const { 
    resolution, 
    frameRate, 
    aspectRatio,
    zoom,
    focusMode,
    exposureCompensation,
    whiteBalance
  } = cameraSettings;
  
  const { batteryOptimization } = systemSettings;
  
  let width, height;
  
  // Calculate base resolution
  switch (resolution) {
    case '1080p':
      width = { ideal: 1920 };
      height = { ideal: 1080 };
      break;
    case '720p':
      width = { ideal: 1280 };
      height = { ideal: 720 };
      break;
    case '480p':
      width = { ideal: 640 };
      height = { ideal: 480 };
      break;
  }
  
  // Adjust for aspect ratio
  if (aspectRatio !== '16:9') {
    if (aspectRatio === '4:3') {
      if (resolution === '1080p') {
        width = { ideal: 1440 };
        height = { ideal: 1080 };
      } else if (resolution === '720p') {
        width = { ideal: 960 };
        height = { ideal: 720 };
      } else {
        width = { ideal: 640 };
        height = { ideal: 480 };
      }
    } else if (aspectRatio === '1:1') {
      if (resolution === '1080p') {
        width = { ideal: 1080 };
        height = { ideal: 1080 };
      } else if (resolution === '720p') {
        width = { ideal: 720 };
        height = { ideal: 720 };
      } else {
        width = { ideal: 480 };
        height = { ideal: 480 };
      }
    }
  }
  
  // Apply battery optimization if enabled
  let adjustedFrameRate: 15 | 30 | 60 = frameRate;
  if (batteryOptimization) {
    // Lower frame rate - ensure we're using a valid framerate value
    adjustedFrameRate = 15; // Fixed at 15 when battery optimization is on
    
    // Step down one resolution level
    if (resolution === '1080p') {
      width = { ideal: 1280 };
      height = { ideal: 720 };
    } else if (resolution === '720p') {
      width = { ideal: 640 };
      height = { ideal: 480 };
    } else {
      width = { ideal: 320 };
      height = { ideal: 240 };
    }
  }
  
  // Build advanced constraints
  const advanced: MediaTrackConstraintSet[] = [];
  
  // Add white balance if not auto
  if (whiteBalance !== 'auto') {
    let whiteBalanceMode;
    switch (whiteBalance) {
      case 'sunny': whiteBalanceMode = 'continuous'; break;
      case 'cloudy': whiteBalanceMode = 'manual'; break;
      case 'fluorescent': whiteBalanceMode = 'single-shot'; break;
      case 'incandescent': whiteBalanceMode = 'manual'; break;
      default: whiteBalanceMode = 'continuous';
    }
    
    advanced.push({ 
      whiteBalanceMode,
      colorTemperature: {
        sunny: 5500,
        cloudy: 6500,
        fluorescent: 4000,
        incandescent: 2700
      }[whiteBalance]
    } as unknown as MediaTrackConstraintSet);
  }
  
  // Add battery optimization constraints if needed
  if (batteryOptimization) {
    advanced.push({
      videoQualityLevel: { ideal: 0.5 }
    } as unknown as MediaTrackConstraintSet);
  }
  
  // Calculate numeric aspect ratio for constraint
  const aspectRatioValue = 
    aspectRatio === '16:9' ? 16/9 : 
    aspectRatio === '4:3' ? 4/3 : 1;
  
  // Create video constraints with better browser compatibility
  const videoConstraints: MediaTrackConstraints = {
    width,
    height,
    frameRate: { ideal: adjustedFrameRate },
    facingMode: { ideal: facingMode },
    aspectRatio: { ideal: aspectRatioValue }
  };
  
  // Add optional advanced constraints only for browsers that support them
  // This approach prevents errors on browsers that don't support these properties
  
  // Add advanced constraints if any
  if (advanced.length > 0) {
    videoConstraints.advanced = advanced;
  }
  
  return videoConstraints;
}

// Generate an optimized SDP with appropriate bitrates
export function setMediaBitrates(
  sdp: string, 
  quality: 'low' | 'balanced' | 'high', 
  maxBitrate?: number
): string {
  // If no SDP is provided, return as is
  if (!sdp) return sdp;
  
  let videoBitrate: number; // in kbps
  let audioBitrate = 64;
  
  // Determine video bitrate based on quality or user-specified bitrate
  if (maxBitrate) {
    // Use user-specified bitrate if provided
    videoBitrate = maxBitrate;
  } else {
    switch (quality) {
      case 'high':
        videoBitrate = 3000; // 3 Mbps
        audioBitrate = 128;  // 128 kbps audio (stereo high quality)
        break;
      case 'balanced':
        videoBitrate = 1500; // 1.5 Mbps
        audioBitrate = 96;   // 96 kbps audio (better quality mono)
        break;
      case 'low':
        videoBitrate = 500;  // 500 Kbps
        audioBitrate = 64;   // 64 kbps audio (standard quality mono)
        break;
      default:
        videoBitrate = 1500;
        audioBitrate = 96;
    }
  }
  
  try {
    // Log original SDP for debugging
    console.log("Setting audio and video bitrates in SDP");
    
    // Simple and safe approach for b=AS bandwidth attribute
    // Only add bandwidth attribute after mid lines
    sdp = sdp.replace(
      /a=mid:video\r\n/g, 
      `a=mid:video\r\nb=AS:${videoBitrate}\r\n`
    );
    
    sdp = sdp.replace(
      /a=mid:audio\r\n/g, 
      `a=mid:audio\r\nb=AS:${audioBitrate}\r\n`
    );
    
    // Ensure audio is not disabled
    if (sdp.includes('a=recvonly') && !sdp.includes('a=sendrecv')) {
      console.log("Converting recvonly to sendrecv for audio");
      sdp = sdp.replace(/a=recvonly/g, 'a=sendrecv');
    }
    
    // Ensure opus codec has stereo enabled for better audio quality
    if (sdp.includes('opus/48000')) {
      console.log("Enhancing opus audio codec parameters");
      sdp = sdp.replace(
        /a=rtpmap:(\d+) opus\/48000\/2/g,
        'a=rtpmap:$1 opus/48000/2\r\na=fmtp:$1 minptime=10;useinbandfec=1;stereo=1'
      );
    }
    
    // NOTE: We avoid complex fmtp modifications that caused the SDP parsing error
    // The b=AS attribute should be sufficient for basic bitrate control
    
    return sdp;
  } catch (error) {
    console.error('Error modifying SDP:', error);
    // If any error occurs, return the original SDP
    return sdp;
  }
}

// Estimate network quality with improved reliability
export function estimateNetworkQuality(): Promise<'low' | 'medium' | 'high'> {
  return new Promise((resolve) => {
    let completed = false;
    
    // Try two methods in parallel:
    // 1. Image download test
    const imageTest = new Promise<void>((resolveImage) => {
      const startTime = Date.now();
      const testImage = new Image();
      
      testImage.onload = () => {
        if (completed) return;
        
        const duration = Date.now() - startTime;
        resolveImage();
        
        if (duration < 100) {
          completed = true;
          resolve('high');
        } else if (duration < 500) {
          completed = true;
          resolve('medium');
        } else {
          completed = true;
          resolve('low');
        }
      };
      
      testImage.onerror = () => {
        resolveImage();
        // Don't resolve the main promise here, let fetch test also run
      };
      
      // Load a small test image (1x1 transparent pixel)
      testImage.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
    });
    
    // 2. Fetch test
    const fetchTest = new Promise<void>((resolveFetch) => {
      // Try to fetch small test images with a timeout
      const imageUrls = [
        'https://www.google.com/images/phd/px.gif',
        'https://www.bing.com/favicon.ico'
      ];
      
      const startTime = Date.now();
      
      // Try multiple URLs in case one is blocked
      Promise.any(imageUrls.map(url => 
        fetch(url, { 
          cache: 'no-store',
          mode: 'no-cors',
          credentials: 'omit' 
        })
      ))
      .then(() => {
        if (completed) return;
        
        const endTime = Date.now();
        const latency = endTime - startTime;
        resolveFetch();
        
        if (latency < 100) {
          completed = true;
          resolve('high');
        } else if (latency < 300) {
          completed = true;
          resolve('medium');
        } else {
          completed = true;
          resolve('low');
        }
      })
      .catch(() => {
        resolveFetch();
        // Don't resolve the main promise here
      });
    });
    
    // Set a timeout for both tests
    Promise.all([imageTest, fetchTest])
      .then(() => {
        if (!completed) {
          completed = true;
          resolve('medium'); // Default to medium if tests are inconclusive
        }
      });
    
    // Final fallback
    setTimeout(() => {
      if (!completed) {
        completed = true;
        resolve('medium');
      }
    }, 2000);
  });
}
