import { useState, useEffect } from 'react';

interface BatteryManager extends EventTarget {
  charging: boolean;
  chargingTime: number;
  dischargingTime: number;
  level: number;
  addEventListener(type: string, listener: EventListenerOrEventListenerObject): void;
  removeEventListener(type: string, listener: EventListenerOrEventListenerObject): void;
}

interface NavigatorWithBattery extends Navigator {
  getBattery?: () => Promise<BatteryManager>;
}

export function useBattery() {
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [isCharging, setIsCharging] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  
  useEffect(() => {
    let battery: BatteryManager | null = null;
    
    const updateBatteryStatus = (b: BatteryManager) => {
      setBatteryLevel(b.level);
      setIsCharging(b.charging);
    };
    
    const setup = async () => {
      try {
        // Check if Battery API is available
        if ((navigator as NavigatorWithBattery).getBattery) {
          battery = await (navigator as NavigatorWithBattery).getBattery!();
          
          updateBatteryStatus(battery);
          
          // Add event listeners for battery status changes
          battery.addEventListener('levelchange', () => updateBatteryStatus(battery!));
          battery.addEventListener('chargingchange', () => updateBatteryStatus(battery!));
        } else {
          console.log('Battery API not supported');
        }
      } catch (err) {
        console.error('Battery API error:', err);
        setError(err instanceof Error ? err : new Error('Battery API error'));
      }
    };
    
    setup();
    
    return () => {
      if (battery) {
        battery.removeEventListener('levelchange', () => updateBatteryStatus(battery!));
        battery.removeEventListener('chargingchange', () => updateBatteryStatus(battery!));
      }
    };
  }, []);
  
  return {
    batteryLevel,
    isCharging,
    error
  };
}
