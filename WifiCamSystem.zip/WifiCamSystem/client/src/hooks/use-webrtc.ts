import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { ConnectionSettings } from '@shared/schema';
import { configurePeerConnection, setMediaBitrates } from '@/lib/webrtc';

interface RTCPeerState {
  pc: RTCPeerConnection;
  iceCandidates: RTCIceCandidate[];
}

export function useWebRTC(localStream: MediaStream | null, connectionSettings?: ConnectionSettings) {
  const [connections, setConnections] = useState<Map<string, RTCPeerState>>(new Map());
  const [connectionState, setConnectionState] = useState<'new' | 'connecting' | 'connected' | 'disconnected' | 'failed'>('new');
  const [error, setError] = useState<Error | null>(null);
  
  // Store ice candidates until the remote description is set
  const pendingIceCandidates = useRef<Map<string, RTCIceCandidate[]>>(new Map());
  
  // Create WebRTC configuration using the provided settings
  const configuration = useMemo(() => {
    // If no settings provided, use a default configuration
    if (!connectionSettings) {
      return {
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
        ]
      };
    }
    
    // Determine ICE servers based on settings
    const iceServers = [];
    
    // Add STUN servers if enabled
    if (connectionSettings.useStunServers) {
      iceServers.push(
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' },
        { urls: 'stun:stun2.l.google.com:19302' },
        { urls: 'stun:stun3.l.google.com:19302' },
        { urls: 'stun:stun4.l.google.com:19302' }
      );
    }
    
    // Add TURN servers if enabled
    if (connectionSettings.useTurnServers) {
      iceServers.push({
        urls: 'turn:openrelay.metered.ca:80',
        username: 'openrelayproject',
        credential: 'openrelayproject'
      });
    }
    
    return {
      iceServers,
      iceTransportPolicy: connectionSettings.iceTransportPolicy,
      iceCandidatePoolSize: 10
    };
  }, [connectionSettings]);
  
  // Create an offer for a new peer
  const createOffer = useCallback(async (peerId: string, stream: MediaStream) => {
    try {
      if (!stream) {
        throw new Error('Cannot create offer: No local stream available');
      }
      
      // Create new peer connection
      const pc = new RTCPeerConnection(configuration);
      
      try {
        // Add all tracks from the local stream
        const tracks = stream.getTracks();
        console.log(`Adding ${tracks.length} tracks to peer connection:`, 
          tracks.map(t => `${t.kind} (${t.label})`).join(', '));
        
        // Log audio tracks specifically
        const audioTracks = stream.getAudioTracks();
        console.log(`Stream has ${audioTracks.length} audio tracks`);
        
        // Add all tracks to the peer connection
        tracks.forEach(track => {
          try {
            pc.addTrack(track, stream);
          } catch (trackError) {
            console.error('Error adding track to peer connection:', trackError);
            // Continue with other tracks
          }
        });
      } catch (tracksError) {
        console.error('Error processing stream tracks:', tracksError);
        // Continue with connection setup despite track errors
      }
      
      // Store ice candidates that arrive before remote description is set
      pc.onicecandidate = (event) => {
        try {
          if (event.candidate) {
            const currentPeerState = connections.get(peerId);
            if (currentPeerState) {
              const updatedIceCandidates = [...currentPeerState.iceCandidates, event.candidate];
              setConnections(prev => {
                const newMap = new Map(prev);
                newMap.set(peerId, {
                  ...currentPeerState,
                  iceCandidates: updatedIceCandidates
                });
                return newMap;
              });
            }
            
            // Return the candidate for signaling
            return event.candidate;
          }
        } catch (iceError) {
          console.error('Error handling ICE candidate:', iceError);
        }
      };
      
      // Update connection state
      pc.onconnectionstatechange = () => {
        setConnectionState(pc.connectionState as any);
      };
      
      // Create offer
      const offer = await pc.createOffer();
      
      // Apply bitrate and quality constraints if settings are provided
      if (connectionSettings) {
        // Modify the SDP to set appropriate bitrates based on quality
        const qualitySdp = setMediaBitrates(
          offer.sdp!, 
          connectionSettings.streamingQuality,
          connectionSettings.maxBitrate
        );
        
        // Update the offer with the modified SDP
        offer.sdp = qualitySdp;
      }
      
      // Set local description with potentially modified offer
      await pc.setLocalDescription(offer);
      
      // Store the connection
      setConnections(new Map(connections.set(peerId, {
        pc,
        iceCandidates: []
      })));
      
      // Return the offer for signaling
      return pc.localDescription;
      
    } catch (err) {
      console.error('Error creating offer:', err);
      setError(err instanceof Error ? err : new Error('Failed to create offer'));
      return null;
    }
  }, [connections, configuration, connectionSettings]);
  
  // Process an answer from a remote peer
  const processAnswer = useCallback(async (peerId: string, answer: RTCSessionDescriptionInit) => {
    const peerState = connections.get(peerId);
    if (peerState) {
      try {
        await peerState.pc.setRemoteDescription(answer);
        
        // Apply any pending ice candidates
        const pendingCandidates = pendingIceCandidates.current.get(peerId) || [];
        for (const candidate of pendingCandidates) {
          await peerState.pc.addIceCandidate(candidate);
        }
        pendingIceCandidates.current.delete(peerId);
        
        return true;
      } catch (err) {
        console.error('Error processing answer:', err);
        setError(err instanceof Error ? err : new Error('Failed to process answer'));
        return false;
      }
    }
    return false;
  }, [connections]);
  
  // Add an ICE candidate from a remote peer
  const addIceCandidate = useCallback(async (peerId: string, candidate: RTCIceCandidateInit) => {
    const peerState = connections.get(peerId);
    
    if (peerState && peerState.pc.remoteDescription) {
      try {
        await peerState.pc.addIceCandidate(new RTCIceCandidate(candidate));
        return true;
      } catch (err) {
        console.error('Error adding ICE candidate:', err);
        setError(err instanceof Error ? err : new Error('Failed to add ICE candidate'));
        return false;
      }
    } else {
      // Store the candidate until remote description is set
      const pendingCandidates = pendingIceCandidates.current.get(peerId) || [];
      pendingCandidates.push(new RTCIceCandidate(candidate));
      pendingIceCandidates.current.set(peerId, pendingCandidates);
      return true;
    }
  }, [connections]);
  
  // Close a specific peer connection
  const closeConnection = useCallback((peerId: string) => {
    try {
      const peerState = connections.get(peerId);
      if (peerState) {
        try {
          peerState.pc.close();
        } catch (closeError) {
          console.error('Error closing peer connection:', closeError);
          // Continue with cleanup despite close error
        }
        
        // Create a new map to trigger re-render
        setConnections(prev => {
          const newMap = new Map(prev);
          newMap.delete(peerId);
          return newMap;
        });
        
        pendingIceCandidates.current.delete(peerId);
      }
    } catch (error) {
      console.error('Error in closeConnection:', error);
      // Don't rethrow to prevent unhandled promise rejection
    }
  }, [connections]);
  
  // Close all connections
  const closeAllConnections = useCallback(() => {
    connections.forEach((peerState) => {
      peerState.pc.close();
    });
    setConnections(new Map());
    pendingIceCandidates.current.clear();
  }, [connections]);
  
  // Cleanup on unmount
  useEffect(() => {
    return () => {
      closeAllConnections();
    };
  }, [closeAllConnections]);
  
  return {
    createOffer,
    processAnswer,
    addIceCandidate,
    closeConnection,
    closeAllConnections,
    connections,
    connectionState,
    error
  };
}
