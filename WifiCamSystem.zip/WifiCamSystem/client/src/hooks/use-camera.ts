import { useState, useEffect, useCallback } from 'react';
import { CameraSettings } from '@shared/schema';

export function useCamera(settings: CameraSettings) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isFrontCamera, setIsFrontCamera] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // Get resolution constraints based on settings
  const getConstraints = useCallback(() => {
    const getFacingMode = () => isFrontCamera ? 'user' : 'environment';
    
    // Calculate resolution
    let width, height;
    switch (settings.resolution) {
      case '1080p':
        width = { ideal: 1920 };
        height = { ideal: 1080 };
        break;
      case '720p':
        width = { ideal: 1280 };
        height = { ideal: 720 };
        break;
      case '480p':
        width = { ideal: 640 };
        height = { ideal: 480 };
        break;
      default:
        width = { ideal: 1280 };
        height = { ideal: 720 };
    }
    
    // Calculate aspect ratio
    if (settings.aspectRatio !== '16:9') {
      // Adjust dimensions based on aspect ratio
      if (settings.aspectRatio === '4:3') {
        if (settings.resolution === '1080p') {
          width = { ideal: 1440 };
          height = { ideal: 1080 };
        } else if (settings.resolution === '720p') {
          width = { ideal: 960 };
          height = { ideal: 720 };
        } else {
          width = { ideal: 640 };
          height = { ideal: 480 };
        }
      } else if (settings.aspectRatio === '1:1') {
        if (settings.resolution === '1080p') {
          width = { ideal: 1080 };
          height = { ideal: 1080 };
        } else if (settings.resolution === '720p') {
          width = { ideal: 720 };
          height = { ideal: 720 };
        } else {
          width = { ideal: 480 };
          height = { ideal: 480 };
        }
      }
    }
    
    // Build advanced constraints
    const advanced: MediaTrackConstraintSet[] = [];
    
    // Add white balance if not auto
    if (settings.whiteBalance !== 'auto') {
      let whiteBalanceMode;
      switch (settings.whiteBalance) {
        case 'sunny': whiteBalanceMode = 'continuous'; break;
        case 'cloudy': whiteBalanceMode = 'manual'; break;
        case 'fluorescent': whiteBalanceMode = 'single-shot'; break;
        case 'incandescent': whiteBalanceMode = 'manual'; break;
        default: whiteBalanceMode = 'continuous';
      }
      
      advanced.push({ 
        whiteBalanceMode,
        colorTemperature: {
          sunny: 5500,
          cloudy: 6500,
          fluorescent: 4000,
          incandescent: 2700
        }[settings.whiteBalance]
      } as unknown as MediaTrackConstraintSet);
    }
    
    // Create video constraints
    const videoConstraints: MediaTrackConstraints = {
      width,
      height,
      frameRate: { ideal: settings.frameRate },
      facingMode: getFacingMode(),
      aspectRatio: settings.aspectRatio === '16:9' 
        ? { ideal: 16/9 } 
        : settings.aspectRatio === '4:3' 
          ? { ideal: 4/3 } 
          : { ideal: 1 },
      // Cast to any to bypass TypeScript's strict MediaTrackConstraints typing
      // These properties are supported in many browsers but not in the TypeScript definition
      ...(settings.focusMode ? { focusMode: settings.focusMode } as any : {}),
      ...(settings.zoom ? { zoom: { ideal: settings.zoom } } as any : {}),
      ...(settings.exposureCompensation !== undefined ? { exposureCompensation: { ideal: settings.exposureCompensation } } as any : {})
    };
    
    // Add advanced constraints if any
    if (advanced.length > 0) {
      videoConstraints.advanced = advanced;
    }
    
    return {
      audio: true, // Enable audio for streaming and recording
      video: videoConstraints
    };
  }, [isFrontCamera, settings]);
  
  // Initialize camera with permissions
  const requestPermissions = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // First check if the API is available
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Media devices API not available in this browser');
      }
      
      // Stop any existing stream
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      
      // Get new stream with current constraints
      const newStream = await navigator.mediaDevices.getUserMedia(getConstraints());
      setStream(newStream);
      
      // Try to enable flash if requested
      if (settings.useFlash) {
        try {
          const track = newStream.getVideoTracks()[0];
          // Use type assertion to handle non-standard capabilities
          const capabilities = track.getCapabilities ? track.getCapabilities() : {};
          if (track && capabilities && (capabilities as any).torch) {
            await track.applyConstraints({ 
              advanced: [{ torch: true } as any] 
            });
          }
        } catch (flashError) {
          console.warn('Flash not supported:', flashError);
        }
      }
      
    } catch (err) {
      console.error('Camera access error:', err);
      setError(err instanceof Error ? err : new Error('Failed to access camera'));
    } finally {
      setIsLoading(false);
    }
  }, [stream, getConstraints, settings.useFlash]);
  
  // Switch between front and back cameras
  const toggleCamera = useCallback(async () => {
    setIsFrontCamera(prev => !prev);
    // Camera will be reinitialized due to dependency change
  }, []);
  
  // Apply new settings when they change
  useEffect(() => {
    if (stream) {
      requestPermissions();
    }
  }, [settings, isFrontCamera]);
  
  // Cleanup stream on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);
  
  return {
    stream,
    isFrontCamera,
    toggleCamera,
    error,
    isLoading,
    requestPermissions
  };
}
