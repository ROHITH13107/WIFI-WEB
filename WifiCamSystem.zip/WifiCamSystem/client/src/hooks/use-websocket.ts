import { useState, useEffect, useCallback, useRef } from 'react';
import { SignalingMessage } from '@shared/schema';

// Maximum number of consecutive reconnection attempts
const MAX_RECONNECT_ATTEMPTS = 10;

// Initial delay before first reconnection attempt (in ms)
const INITIAL_RECONNECT_DELAY = 1000;

// Maximum delay between reconnection attempts (in ms)
const MAX_RECONNECT_DELAY = 30000;

// Heartbeat interval (in ms) - Send a ping every 30 seconds
const HEARTBEAT_INTERVAL = 30000;

// Jitter factor for reconnection delay (0-1)
const JITTER_FACTOR = 0.2;

// Calculate exponential backoff delay with jitter
const calculateBackoff = (attempt: number): number => {
  // Base exponential delay: min(initial * (2^attempt), max_delay)
  const exponentialDelay = Math.min(
    INITIAL_RECONNECT_DELAY * Math.pow(2, attempt),
    MAX_RECONNECT_DELAY
  );
  
  // Add random jitter to prevent synchronized reconnection attempts
  // Random value between -JITTER_FACTOR and +JITTER_FACTOR of the delay
  const jitter = (Math.random() * 2 - 1) * JITTER_FACTOR * exponentialDelay;
  
  return Math.floor(exponentialDelay + jitter);
};

export function useWebSocket() {
  const [connected, setConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<string | null>(null);
  const [error, setError] = useState<Error | null>(null);
  
  // Use ref to maintain websocket instance across renders
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<number | null>(null);
  const heartbeatIntervalRef = useRef<number | null>(null);
  const reconnectAttempts = useRef<number>(0);
  const isConnecting = useRef<boolean>(false);
  
  // Create a new WebSocket connection with enhanced reliability for Replit
  const connect = useCallback(() => {
    // Prevent multiple simultaneous connection attempts
    if (isConnecting.current) {
      console.log('Already attempting to connect, skipping duplicate request');
      return;
    }
    
    try {
      isConnecting.current = true;
      setError(null);
      
      // Safely close existing connection if any
      if (socketRef.current) {
        try {
          // Check if the socket is not already closing or closed
          if (socketRef.current.readyState !== WebSocket.CLOSING && 
              socketRef.current.readyState !== WebSocket.CLOSED) {
            socketRef.current.close();
          }
        } catch (closeError) {
          console.warn('Error closing existing WebSocket:', closeError);
        }
        
        // Clear the reference regardless of close success
        socketRef.current = null;
      }
      
      // Construct a reliable WebSocket URL that works in all environments
      // Log current URL for debugging
      console.log('Current URL:', window.location.href);
      
      // Get the current hostname from the URL
      const hostname = window.location.hostname;
      const port = window.location.port || (window.location.protocol === 'https:' ? '443' : '80');
      
      // Use the most direct approach possible to avoid URL construction issues
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${hostname}:${port}/ws`;
      
      // Log the WebSocket URL for debugging
      console.log('WebSocket URL should be:', wsUrl);
      
      console.log(`Connecting to WebSocket at URL: ${wsUrl} (from ${window.location.href})`);
      
      // Create new socket with a short timeout for connection verification
      const socket = new WebSocket(wsUrl);
      
      // Important: Store the socket reference immediately to prevent race conditions
      socketRef.current = socket;
      
      // Define the heartbeat function
      const startHeartbeat = () => {
        // Clear any existing heartbeat interval
        if (heartbeatIntervalRef.current) {
          window.clearInterval(heartbeatIntervalRef.current);
        }
        
        // Create a new heartbeat interval
        heartbeatIntervalRef.current = window.setInterval(() => {
          try {
            // Only send ping if socket is open
            if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
              console.log('Sending heartbeat ping...');
              // Using a simple ping message
              socketRef.current.send(JSON.stringify({ type: 'ping' }));
            }
          } catch (pingError) {
            console.error('Error sending heartbeat ping:', pingError);
          }
        }, HEARTBEAT_INTERVAL);
      };
      
      // Properly typed event handler for open event
      socket.onopen = (event: Event) => {
        console.log('WebSocket connection established');
        setConnected(true);
        setError(null);
        isConnecting.current = false;
        
        // Reset reconnect attempts counter on successful connection
        reconnectAttempts.current = 0;
        
        // Clear any reconnect timeout
        if (reconnectTimeoutRef.current) {
          window.clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = null;
        }
        
        // Start heartbeat to keep connection alive
        startHeartbeat();
      };
      
      // Properly typed event handler for message event
      socket.onmessage = (event: MessageEvent) => {
        try {
          console.log('WebSocket message received:', event.data);
          
          // Check for welcome message directly to improve reliability
          try {
            const data = JSON.parse(event.data);
            // Handle welcome message immediately here
            if (data.type === 'welcome') {
              console.log('Received welcome message from server - connection now fully established');
              
              // Define a custom event that components can listen for
              const welcomeEvent = new CustomEvent('websocket-welcome', {
                detail: { message: data.message }
              });
              window.dispatchEvent(welcomeEvent);
            } else if (data.type === 'pong') {
              console.log('Received heartbeat pong from server');
              return; // Don't process pongs further
            }
          } catch (parseError) {
            // Not JSON or not a pong, continue with normal message handling
            console.warn('Failed to parse WebSocket message as JSON:', parseError);
          }
          
          // Set the message for other components to process
          setLastMessage(event.data);
        } catch (messageError) {
          console.error('Error processing WebSocket message:', messageError);
        }
      };
      
      // Properly typed event handler for error event
      socket.onerror = (event: Event) => {
        console.error('WebSocket error:', event);
        setError(new Error('WebSocket connection failed'));
        isConnecting.current = false;
        
        // Don't set connected to false here, let onclose handle it
        // This prevents double reconnection attempts
      };
      
      // Properly typed event handler for close event
      socket.onclose = (event: CloseEvent) => {
        console.log('WebSocket connection closed:', event.code, event.reason);
        setConnected(false);
        isConnecting.current = false;
        
        // Clear heartbeat interval
        if (heartbeatIntervalRef.current) {
          window.clearInterval(heartbeatIntervalRef.current);
          heartbeatIntervalRef.current = null;
        }
        
        // Clear any existing reconnect timeout
        if (reconnectTimeoutRef.current) {
          window.clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = null;
        }
        
        // Apply exponential backoff with jitter, but only if we're below max attempts
        if (reconnectAttempts.current < MAX_RECONNECT_ATTEMPTS) {
          const backoffTime = calculateBackoff(reconnectAttempts.current);
          reconnectAttempts.current += 1;
          
          console.log(`Scheduling reconnect in ${backoffTime}ms (attempt ${reconnectAttempts.current}/${MAX_RECONNECT_ATTEMPTS})`);
          
          // Attempt to reconnect after a delay
          reconnectTimeoutRef.current = window.setTimeout(() => {
            console.log(`Attempting to reconnect WebSocket (attempt ${reconnectAttempts.current}/${MAX_RECONNECT_ATTEMPTS})...`);
            // Only reconnect if component is still mounted
            connect();
          }, backoffTime);
        } else {
          console.log(`Maximum reconnect attempts (${MAX_RECONNECT_ATTEMPTS}) reached. Giving up.`);
          setError(new Error(`Failed to connect after ${MAX_RECONNECT_ATTEMPTS} attempts. Please refresh the page.`));
        }
      };
      
      // socketRef already set earlier
      
    } catch (err) {
      console.error('Error creating WebSocket:', err);
      setError(err instanceof Error ? err : new Error('Failed to create WebSocket connection'));
      isConnecting.current = false;
    }
  }, []);
  
  // Send a message through the WebSocket with safety checks
  const sendMessage = useCallback((message: SignalingMessage) => {
    try {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        console.log('Sending WebSocket message:', message);
        socketRef.current.send(JSON.stringify(message));
        return true;
      } else {
        console.warn('Cannot send message, WebSocket is not connected');
        return false;
      }
    } catch (sendError) {
      console.error('Error sending message:', sendError);
      return false;
    }
  }, []);
  
  // Disconnect the WebSocket with safeguards
  const disconnect = useCallback(() => {
    try {
      if (socketRef.current) {
        // Only attempt to close if not already closing or closed
        if (socketRef.current.readyState !== WebSocket.CLOSING && 
            socketRef.current.readyState !== WebSocket.CLOSED) {
          socketRef.current.close();
        }
        socketRef.current = null;
      }
      
      setConnected(false);
      
      // Clear any reconnect timeout
      if (reconnectTimeoutRef.current) {
        window.clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }
      
      // Clear any heartbeat interval
      if (heartbeatIntervalRef.current) {
        window.clearInterval(heartbeatIntervalRef.current);
        heartbeatIntervalRef.current = null;
      }
    } catch (disconnectError) {
      console.error('Error disconnecting WebSocket:', disconnectError);
    }
  }, []);
  
  // Cleanup on unmount with safeguards
  useEffect(() => {
    return () => {
      try {
        // Clean up WebSocket connection
        if (socketRef.current) {
          // Only attempt to close if not already closing or closed
          if (socketRef.current.readyState !== WebSocket.CLOSING && 
              socketRef.current.readyState !== WebSocket.CLOSED) {
            socketRef.current.close();
          }
        }
        
        // Clear all timers and intervals
        if (reconnectTimeoutRef.current) {
          window.clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = null;
        }
        
        if (heartbeatIntervalRef.current) {
          window.clearInterval(heartbeatIntervalRef.current);
          heartbeatIntervalRef.current = null;
        }
      } catch (cleanupError) {
        console.error('Error during WebSocket cleanup:', cleanupError);
      }
    };
  }, []);
  
  return {
    connect,
    disconnect,
    sendMessage,
    connected,
    lastMessage,
    error
  };
}
