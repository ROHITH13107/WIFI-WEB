import React from 'react';
import { Switch, Route } from "wouter";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "./components/ThemeProvider";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Camera from "@/pages/Camera";
import Viewer from "@/pages/Viewer";

// Router component for navigation
const Router: React.FC = () => {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/camera/:roomId?" component={Camera} />
      <Route path="/viewer/:roomId?" component={Viewer} />
      <Route component={NotFound} />
    </Switch>
  );
};

// Main application component
const App: React.FC = () => {
  return (
    <ThemeProvider defaultTheme="system" storageKey="wifi-camera-theme">
      <TooltipProvider>
        <Router />
        <Toaster />
      </TooltipProvider>
    </ThemeProvider>
  );
};

export default App;
