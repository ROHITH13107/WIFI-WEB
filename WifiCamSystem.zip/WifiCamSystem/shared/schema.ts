import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  roomId: text("room_id").notNull().unique(),
  hostId: text("host_id").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: text("created_at").notNull(),
});

// Types for WebRTC signaling
export type SignalingMessage = {
  type: 'offer' | 'answer' | 'ice-candidate' | 'leave' | 'join' | 'permission-request' | 'permission-response' | 'recording-state' | 'ping' | 'pong';
  roomId: string;
  senderId: string;
  receiverId?: string;
  data?: any;
  timestamp?: number; // Used for ping/pong messages
};

// Viewer permission levels
export type ViewerPermission = 'view' | 'admin' | 'blocked';

// Viewer info with permissions
export type ViewerInfo = {
  id: string;
  permission: ViewerPermission;
  nickname?: string;
  joinedAt: number; // timestamp
};

// Recording state information
export type RecordingState = {
  isRecording: boolean;
  startTime?: number;
  duration?: number;
  fileName?: string;
};

export type CameraSettings = {
  // Basic settings
  resolution: '480p' | '720p' | '1080p';
  frameRate: 15 | 30 | 60;
  useFlash: boolean;
  
  // Enhanced settings
  aspectRatio: '16:9' | '4:3' | '1:1';
  focusMode: 'auto' | 'continuous' | 'manual';
  zoom: number; // 1.0 - 5.0
  whiteBalance: 'auto' | 'sunny' | 'cloudy' | 'fluorescent' | 'incandescent';
  exposureCompensation: number; // -2 to +2
};

export type ConnectionSettings = {
  // Basic settings
  autoReconnect: boolean;
  streamingQuality: 'low' | 'balanced' | 'high';
  
  // Enhanced settings
  maxBitrate: number; // in kbps
  keyframeInterval: number; // in seconds
  iceTransportPolicy: 'all' | 'relay'; // Use relay for better NAT traversal
  useDtls: boolean; // DTLS encryption
  useStunServers: boolean; // Use public STUN servers
  useTurnServers: boolean; // Use TURN fallback
};

export type SystemSettings = {
  // Basic settings
  keepScreenOn: boolean;
  batteryOptimization: boolean;
  
  // Enhanced settings
  recordSessions: boolean; // Record sessions locally
  notifyOnViewerConnect: boolean; // Display notification when viewers connect
  privacyMode: boolean; // Blur background or apply privacy filters
  deviceNickname: string; // Friendly name for the device
};

export type AppSettings = {
  camera: CameraSettings;
  connection: ConnectionSettings;
  system: SystemSettings;
};

export const defaultSettings: AppSettings = {
  camera: {
    // Basic settings
    resolution: '720p',
    frameRate: 30,
    useFlash: false,
    
    // Enhanced settings
    aspectRatio: '16:9',
    focusMode: 'auto',
    zoom: 1.0,
    whiteBalance: 'auto',
    exposureCompensation: 0
  },
  connection: {
    // Basic settings
    autoReconnect: true,
    streamingQuality: 'balanced',
    
    // Enhanced settings
    maxBitrate: 1000, // 1 Mbps as default
    keyframeInterval: 2, // 2 seconds
    iceTransportPolicy: 'all',
    useDtls: true,
    useStunServers: true,
    useTurnServers: false
  },
  system: {
    // Basic settings
    keepScreenOn: true,
    batteryOptimization: false,
    
    // Enhanced settings
    recordSessions: false,
    notifyOnViewerConnect: true,
    privacyMode: false,
    deviceNickname: 'WiFi Camera'
  }
};

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
